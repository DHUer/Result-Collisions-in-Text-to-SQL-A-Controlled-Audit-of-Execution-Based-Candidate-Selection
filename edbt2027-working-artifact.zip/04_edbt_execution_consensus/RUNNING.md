# Run and reproduce

All commands below start in `paper/04_edbt_execution_consensus/`. Python 3.10+
and a current SQLite are required; Python 3.12 is the tested version. The core
pipeline additionally requires pinned `sqlparse==0.5.3` for DAIL-SQL preprocessing.
Figures use Matplotlib.

## 1. Environment and public assets

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[figures]'
python scripts/prepare_assets.py template spider testsuite
collision-audit prepare
python -m unittest discover -s tests -v
```

The original download archives total about 1.5 GB, plus expanded databases.
Reserve at least 15 GB free for datasets, runs and models. Asset hashes are pinned;
if an official download changes, the script stops instead of silently replacing
the study. Google Drive's ordinary large-file confirmation is handled; access
denials or unexpected HTML are not bypassed. Manual ZIP extraction is unnecessary.

## 2. Local model generation

Install a CUDA-enabled llama.cpp `llama-server` on the RTX 5080, or the Metal build
on Apple Silicon. Supply a model file you are licensed to use. The existing pilot
uses Qwen2.5-3B-Instruct Q8_0 and Llama-3.2-3B-Instruct Q8_0, each about 3–4 GB.
Record the binary version; different backends are separate experimental runs.

```bash
python scripts/run_local.py \
  --model /absolute/path/qwen2.5-3b-instruct-q8_0.gguf \
  --model-id qwen2.5-3b-instruct-q8_0 \
  --split pilot --run runs/my_qwen_pilot --port 18089
```

The script checks that the port is free, launches only its own server on loopback,
waits for health, records provenance, generates five samples per question, and
stops its server on completion/failure. It never stops a preexisting service.
Rerunning with the same files/settings resumes completed calls; a changed model,
input, generation source or setting requires a new run directory. A crashed run
may leave `generation.lock`; inspect for a live process before removing that one
lock file. Do not run two writers against the same directory.

Repeat with the Llama file, a distinct `--model-id`, and a different run directory.
Do not mix candidates from models or from different machines to form a vote pool.

To use a server you launched yourself, use `collision-audit generate --help`.
The low-level runner verifies the advertised model alias, but cannot prove that
an independently managed server loaded the file passed as `--model-path`; preserve
the actual server command/log. Prefer `run_local.py` for the confirmation study.

## 3. Freeze selection, then score

```bash
collision-audit select \
  --run runs/my_qwen_pilot --inputs data/processed/pilot.inputs.jsonl
collision-audit evaluate \
  --run runs/my_qwen_pilot --labels data/processed/pilot.labels.jsonl
collision-audit report \
  --run runs/my_qwen_pilot --output reports/my_qwen_pilot \
  --label 'Exploratory pilot: local Qwen run'
```

Generation and selection cannot consume the label file through their input
schema. Evaluation verifies frozen selection hashes, loads labels separately,
executes all suite instances, and checkpoints by question. Keep all manifests
and raw ledgers. Gold failures are reported, not silently counted as correct or
dropped from only one method. Candidate timeouts count as failures.

Read-only execution rejects writes, ATTACH, PRAGMAs, extensions, multiple statements,
unapproved functions and oversized results. It has SQL progress and process
deadlines. It is **not a full OS sandbox** for hostile database files. Use only
the pinned public databases, or add a disposable container for untrusted inputs.

## 4. Confirmation on the RTX 5080

The local study's immutable freeze is `docs/confirmation_lock.json`; its source,
protocol and configuration snapshot is `docs/confirmation_lock.zip`. Do not
rewrite this lock or the measured run directories. To reproduce the same protocol
on the RTX 5080, use the existing lock and a **new** run directory. New hardware
does not make the already analyzed data a fresh holdout.

```bash
python scripts/run_local.py \
  --model /absolute/path/qwen2.5-3b-instruct-q8_0.gguf \
  --model-id qwen2.5-3b-instruct-q8_0 \
  --split confirmation --run runs/rtx_replication_qwen3b \
  --protocol-lock docs/confirmation_lock.json --port 18089
collision-audit select \
  --run runs/rtx_replication_qwen3b --inputs data/processed/confirmation.inputs.jsonl
collision-audit evaluate \
  --run runs/rtx_replication_qwen3b --labels data/processed/confirmation.labels.jsonl --workers 4
collision-audit report \
  --run runs/rtx_replication_qwen3b --output reports/rtx_replication_qwen3b \
  --label 'RTX replication: Qwen2.5-3B Q8_0'
```

The freeze script records a local manifest; it is **not** independent registration
and does not certify that scientific readiness gates have been satisfied. Review
them explicitly. There are 4,330 calls per model, 8,660 for two families. No claim
about completion time on the uninspected RTX 5080 is made.

Machines need not work together. The Mac Studio can run the second family while
the RTX generates the first. Copy a **complete** run plus its manifests for CPU
evaluation elsewhere; maintain immutable candidate pools. Do not infer hardware
performance from different models or changing decode settings.

## 5. Regenerate tables, figures and paper

The final paper uses both retained pilot reports and the two confirmation reports.
For a full fresh confirmation run in this local workspace, `run_confirmation.py`
orchestrates both models and stops generation before scoring (its paths are local
defaults; use the portable commands above on another machine). After primary
scoring, run robustness and verification:

```bash
python scripts/audit_constraints.py
python scripts/analyze_confirmation.py
python scripts/run_sensitivity.py
python scripts/diagnose_gold_row_caps.py
PYTHONWARNINGS=ignore::SyntaxWarning python scripts/verify_confirmation.py
python scripts/export_confirmation_examples.py
```

These steps need the downloaded databases. Re-rendering from the included compact
reports does **not** require model weights or fresh model calls:

```bash
python scripts/render_paper_assets.py
python scripts/render_confirmation.py
python scripts/prepare_fonts.py
python scripts/build_paper.py --tectonic /absolute/path/to/tectonic
```

The build uses the vendored official EDBT class/macros/bibliography style unchanged.
An older Tectonic bundle lacks the Libertinus Math font requested by the current
class; the font-preparation script supplies that exact font under its SIL OFL,
without changing the conference class or substituting a different font.
The manuscript has numbered references and vector figures generated from measured
report files. A conceptual example is explicitly labeled as constructed.
Paper build and figure manifests record input/output hashes. The PDF is a working
draft with author details pending, not an upload-ready submission.

To verify the included numeric reports and every frozen selector choice without
model inference, run `python scripts/verify_reports.py`. With downloaded data,
add `--execute-witnesses` to re-execute every saved separation witness. This was
done for all 26 pilot witnesses. `verify_confirmation.py` separately checks all
17,320 confirmation decisions, compares DAIL aggregation on all 1,732 pools with
the released code, and re-executes all stored confirmation witnesses. PDF checks are available through
`scripts/inspect_paper.py` with PyMuPDF installed (`pip install pymupdf==1.24.11`).
`python scripts/package_artifact.py` creates a checksum-verified local ZIP of code,
reports and manuscript material, excluding downloaded data and model weights.
`python scripts/verify_artifact_reproduction.py` extracts that ZIP into a fresh
temporary directory, verifies its complete file manifest, runs the unit tests,
and reproduces the report-only analysis plus all tables and PDF/SVG figures.
It requires the Python dependencies but no downloaded databases or model weights.
Its verification report stays outside the ZIP to avoid a self-referential hash.

## 6. Gemma extension (post-confirmation, unchanged protocol)

```bash
python scripts/run_local.py --server llama-server \
  --model /path/to/gemma-4-12b-it-qat-q4_0.gguf --model-id gemma12b \
  --split confirmation --run runs/extension_gemma12b --port 18096 \
  --protocol-lock docs/confirmation_lock.json \
  --server-arg=--reasoning-budget --server-arg=0
python -m collision_audit.cli select --run runs/extension_gemma12b --inputs data/processed/confirmation.inputs.jsonl
python -m collision_audit.cli evaluate --run runs/extension_gemma12b --labels data/processed/confirmation.labels.jsonl --workers 4
python -m collision_audit.cli report --run runs/extension_gemma12b --output reports/extension_gemma12b --label 'Post-confirmation extension: Gemma-4-12B'
python scripts/analyze_extension.py   # writes manuscript/generated/extension_numbers.tex
```

`--server-arg` passes switches to `llama-server` only; request payloads are
unchanged. Measured on the M4 Max: 5,005 s of generation, 0 request failures,
12 token-cap truncations (counted as failed candidates).
