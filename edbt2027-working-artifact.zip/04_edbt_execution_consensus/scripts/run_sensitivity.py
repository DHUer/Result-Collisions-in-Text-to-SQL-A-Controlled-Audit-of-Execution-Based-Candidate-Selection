"""Predeclared balanced 10-second evaluation; frozen selections are unchanged."""
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.audit import evaluate_run
from collision_audit.common import digest, read_json, read_jsonl, stable_hash, write_json, write_jsonl
from collision_audit.selection import METHODS


def derive(name, ids, suffix):
    parent = ROOT / f"runs/confirmation_{name}"
    run = ROOT / f"runs/{suffix}_{name}"
    run.mkdir(exist_ok=True)
    for filename in ("selected.jsonl", "candidates.jsonl"):
        rows = [r for r in read_jsonl(parent / filename) if r["id"] in ids]
        write_jsonl(run / filename, rows)
    write_jsonl(run / "labels.jsonl", [r for r in read_jsonl(ROOT / "data/processed/confirmation.labels.jsonl") if r["id"] in ids])
    write_json(run / "selection_manifest.json", {"selected_sha256": digest(run / "selected.jsonl"), "candidate_sha256": digest(run / "candidates.jsonl"), "parent_selected_sha256": digest(parent / "selected.jsonl"), "unchanged_selection_subset": True})
    evaluate_run(run, run / "labels.jsonl", timeout=10., workers=4)
    return read_jsonl(run / "evaluated.jsonl")


def main():
    start = time.monotonic()
    inputs = read_jsonl(ROOT / "data/processed/confirmation.inputs.jsonl")
    ids = set()
    for db in sorted({r["db_id"] for r in inputs}):
        subset = sorted([r for r in inputs if r["db_id"] == db], key=lambda r: stable_hash(["edbt-timeout-v1", r["id"]]))[:10]
        ids.update(r["id"] for r in subset)
    assert len(ids) == 154  # real_estate_properties has only four public-dev questions
    result = {"script_sha256": digest(Path(__file__)), "panel_ids": sorted(ids), "panel_size": len(ids), "sample_size_correction": "Protocol anticipated 160 incorrectly. Hash ordering is unchanged; real_estate_properties contributes all four available questions. Corrected before sensitivity scoring; see docs/SENSITIVITY_AMENDMENT.md.", "timeout_seconds": 10., "selection": "Unchanged 2-second frozen selection; only scoring is re-executed", "models": {}}
    for name in ("qwen3b", "llama3b"):
        primary = {r["id"]: r for r in read_jsonl(ROOT / f"runs/confirmation_{name}/evaluated.jsonl")}
        longer = derive(name, ids, "sensitivity_10s")
        common = [r for r in longer if r["evaluation_valid"] and primary[r["id"]]["evaluation_valid"]]
        methods = {}
        for m in METHODS:
            p = [bool(primary[r["id"]]["suite_correct"][r["selected"][m]]) for r in common]
            s = [bool(r["suite_correct"][r["selected"][m]]) for r in common]
            methods[m] = {"primary_correct_common": sum(p), "longer_correct_common": sum(s), "common_denominator": len(common), "outcome_changes_common": sum(a != b for a,b in zip(p,s)), "longer_correct_available": sum(r["suite_correct"][r["selected"][m]] for r in longer if r["evaluation_valid"])}
        extra_ids = {i for i, r in primary.items() if not r["evaluation_valid"]} - ids
        extra = derive(name, extra_ids, "gold_failure_diagnostic_10s") if extra_ids else []
        result["models"][name] = {"panel": len(ids), "primary_available": sum(primary[i]["evaluation_valid"] for i in ids), "longer_available": sum(r["evaluation_valid"] for r in longer), "methods": methods, "primary_gold_failure_ids": [i for i,r in primary.items() if not r["evaluation_valid"]], "extra_gold_diagnostic_ids": sorted(extra_ids), "extra_gold_diagnostic_available": sum(r["evaluation_valid"] for r in extra), "candidate_outcome_changes_common": sum(a != b for r in common for a,b in zip(primary[r["id"]]["suite_correct"],r["suite_correct"]))}
        write_jsonl(ROOT / f"reports/sensitivity_10s_{name}.jsonl", longer)
        write_jsonl(ROOT / f"reports/gold_diagnostic_10s_{name}.jsonl", extra)
        write_json(ROOT / f"reports/sensitivity_manifest_{name}.json", read_json(ROOT / f"runs/sensitivity_10s_{name}/evaluation_manifest.json"))
        if extra:
            write_json(ROOT / f"reports/gold_diagnostic_manifest_{name}.json", read_json(ROOT / f"runs/gold_failure_diagnostic_10s_{name}/evaluation_manifest.json"))
        print(name, result["models"][name], flush=True)
    result["elapsed_seconds"] = time.monotonic() - start
    write_json(ROOT / "reports/timeout_sensitivity.json", result)


if __name__ == "__main__":
    main()
