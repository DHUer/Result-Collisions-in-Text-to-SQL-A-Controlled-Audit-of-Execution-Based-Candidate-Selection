"""Generate local page previews for visual review, not paper figures."""
from pathlib import Path
import fitz
ROOT = Path(__file__).resolve().parents[1]


def main():
    source = fitz.open(ROOT / "manuscript/edbt2027-collision-audit-draft.pdf")
    out = ROOT / ".cache/pdf_review"
    out.mkdir(parents=True, exist_ok=True)
    sheet = fitz.open()
    for offset in range(0, len(source), 4):
        page = sheet.new_page(width=842, height=1191)
        for j in range(4):
            i = offset + j
            if i >= len(source):
                break
            rect = fitz.Rect((j % 2)*421, (j//2)*595.5, (j%2+1)*421, (j//2+1)*595.5)
            page.show_pdf_page(rect, source, i)
            source[i].get_pixmap(matrix=fitz.Matrix(1.2,1.2)).save(out / f"page-{i+1}.png")
        page.get_pixmap().save(out / f"sheet-{offset//4+1}.png")
    print(f"Rendered {len(source)} pages to {out}")


if __name__ == "__main__":
    main()
