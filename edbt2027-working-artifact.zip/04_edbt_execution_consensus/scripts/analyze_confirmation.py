"""Paired, cluster-aware analysis of the frozen confirmation ledgers.

No generation, gold editing, query repair, or outcome-dependent subset selection.
The protocol declares primary vs secondary comparisons; intervals are pointwise.
"""
import collections
import random
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, read_jsonl, write_json
from collision_audit.selection import METHODS, choose, groups
from collision_audit.comparator import equivalent


def clustered(rows, values, repeats=4000):
    totals = collections.defaultdict(lambda: [0., 0])
    for row, value in zip(rows, values):
        totals[row["db_id"]][0] += value
        totals[row["db_id"]][1] += 1
    clusters = [totals[k] for k in sorted(totals)]
    rng = random.Random(2701)
    samples = []
    for _ in range(repeats):
        draw = [rng.choice(clusters) for _ in clusters]
        samples.append(sum(t[0] for t in draw) / sum(t[1] for t in draw))
    samples.sort()
    return {"estimate": sum(values) / len(values), "ci95": [samples[int(.025*repeats)], samples[int(.975*repeats)]], "questions": len(values), "clusters": len(clusters)}


def analyze(name, screen, prefix="confirmation"):
    report = ROOT / f"reports/{prefix}_{name}"
    selected = read_jsonl(report / "candidate_audit.jsonl")
    cases = read_jsonl(report / "case_audit.jsonl")
    pools = {r["id"]: r["candidates"] for r in selected}
    valid = [r for r in cases if r["evaluation_valid"]]
    score = lambda r, m: int(r["suite_correct"][r["selected"][m]])
    comparisons = {}
    contrasts = [("execution_bag", "first"), ("first_executable", "first"), ("execution_bag", "first_executable"), ("dail_sc", "execution_official")]
    contrasts += [(m, "execution_bag") for m in ("execution_ordered", "execution_arity_blind", "execution_unique_sql", "execution_official", "dail_sc")]
    for method, baseline in contrasts:
        values = [score(r, method) - score(r, baseline) for r in valid]
        comparisons[method + "_vs_" + baseline] = {
            **clustered(valid, values), "wins": values.count(1), "losses": values.count(-1),
            "selected_index_changes": sum(r["selected"][method] != r["selected"][baseline] for r in cases),
            "selected_sql_changes": sum(pools[r["id"]][r["selected"][method]]["sql"] != pools[r["id"]][r["selected"][baseline]]["sql"] for r in cases),
            "primary": method == "execution_bag" and baseline == "first"}
    uniform = []
    for r in valid:
        executable = [i for i, c in enumerate(pools[r["id"]]) if c["execution"]["status"] == "ok"] or [0]
        uniform.append(sum(r["suite_correct"][i] for i in executable) / len(executable))
    comparisons["execution_bag_vs_uniform_executable"] = {**clustered(valid, [score(r, "execution_bag") - u for r, u in zip(valid, uniform)]), "primary": False, "uniform_expected_correct": sum(uniform)}
    budgets = {}
    for k in (1, 3, 5):
        counts = {m: 0 for m in METHODS}
        for r in valid:
            for m in METHODS:
                counts[m] += int(r["suite_correct"][choose(pools[r["id"]][:k], m)])
        budgets[k] = {"denominator": len(valid), "correct": counts, "oracle_correct": sum(any(r["suite_correct"][:k]) for r in valid)}
    by_db = {}
    for db in sorted({r["db_id"] for r in cases}):
        subset = [r for r in valid if r["db_id"] == db]
        all_subset = [r for r in cases if r["db_id"] == db]
        by_db[db] = {"valid": len(subset), "total": len(all_subset), "correct": {m: sum(score(r, m) for r in subset) for m in METHODS}, "collision_questions": sum(bool(r["witnesses"]) for r in all_subset)}
    screened_cases, screened_counts = [], {m: 0 for m in METHODS}
    screened_pairs = screened_questions = screened_changed_instances = 0
    full_changed_pairs = full_changed_questions = 0
    witness_plan = []
    for r in cases:
        db_screen = screen["databases"][r["db_id"]]
        origin = db_screen["original"]["sha256"]
        chosen = [ins for ins in r["instances"] if db_screen["instances"][ins["database"]]["passed_screen"]]
        changed = [ins for ins in chosen if db_screen["instances"][ins["database"]]["sha256"] != origin]
        all_changed = [ins for ins in r["instances"] if db_screen["instances"][ins["database"]]["sha256"] != origin]
        full_pairs = {tuple(pair) for ins in all_changed for pair in ins["separated_pairs"]}
        pairs = {tuple(pair) for ins in changed for pair in ins["separated_pairs"]}
        full_changed_pairs += len(full_pairs)
        full_changed_questions += bool(full_pairs)
        screened_pairs += len(pairs)
        screened_questions += bool(pairs)
        screened_changed_instances += len(changed)
        for pair in sorted(pairs):
            witness = next(ins for ins in changed if list(pair) in ins["separated_pairs"])
            witness_plan.append({"id": r["id"], "db_id": r["db_id"], "database": witness["database"], "pair": list(pair)})
        if changed and r["gold_original"]["status"] == "ok" and all(ins["gold_status"] == "ok" for ins in chosen):
            screened_cases.append(r["id"])
            correct = [bool(v) for v in r["original_correct"]]
            for ins in chosen:
                correct = [old and new for old, new in zip(correct, ins["candidate_matches"])]
            for m in METHODS:
                screened_counts[m] += int(correct[r["selected"][m]])
    selected_relations = collections.defaultdict(lambda: {"questions": 0, "suite_correct": 0, "original_correct": 0})
    error_decomposition = collections.Counter()
    winning_groups = []
    for r in valid:
        label = "collision_in_pool" if r["witnesses"] else "no_witnessed_collision"
        selected_relations[label]["questions"] += 1
        selected_relations[label]["suite_correct"] += score(r, "execution_bag")
        selected_relations[label]["original_correct"] += int(r["original_correct"][r["selected"]["execution_bag"]])
        pool = pools[r["id"]]
        clusters = groups(pool, "execution_bag")
        winner = min(clusters, key=lambda c: (-len(c), c[0])) if clusters else [0]
        selected_ok = bool(score(r, "execution_bag"))
        group_ok = any(r["suite_correct"][i] for i in winner)
        oracle_ok = any(r["suite_correct"])
        category = "correct_selection" if selected_ok else ("no_correct_candidate" if not oracle_ok else ("correct_candidate_in_winning_group" if group_ok else "correct_candidates_only_outside_winning_group"))
        error_decomposition[category] += 1
        winning_groups.append({"id": r["id"], "db_id": r["db_id"], "group_size": len(winner) if clusters else 0, "distinct_sql": len({pool[i]["sql"].strip() for i in winner}) if clusters else 0, "correct_members": sum(r["suite_correct"][i] for i in winner), "selected_correct": selected_ok, "tied_top_groups": sum(len(c) == len(winner) for c in clusters), "category": category})
    false_reassurance = []
    for r in valid:
        i = r["selected"]["execution_bag"]
        if r["original_correct"][i] and not r["suite_correct"][i]:
            semantic = [ins["database"] for ins in r["instances"] if ins["gold_status"] == ins["candidate_status"][i] == "ok" and not ins["candidate_matches"][i]]
            failures = [ins["database"] for ins in r["instances"] if ins["candidate_status"][i] != "ok"]
            false_reassurance.append({"id": r["id"], "db_id": r["db_id"], "kind": r["candidate_kinds"][i], "successful_mismatch_instances": semantic, "candidate_failure_instances": failures})
    for filename in ("generation_completion.json", "launch_history.jsonl"):
        source = ROOT / f"runs/{prefix}_{name}" / filename
        target = report / filename
        if source.exists() and not target.exists():
            shutil.copy2(source, target)
        if source.exists() and target.exists() and digest(source) != digest(target):
            raise ValueError("Archived generation provenance differs from the raw run")
    generation = read_json(report / "generation_completion.json")
    transforms = collections.Counter()
    import sqlparse
    for row in selected:
        for c in row["candidates"]:
            if c["sql"] == c["dail_voting_sql"]:
                original, repeated = c["execution"], c["dail_execution"]
                if (original["status"] == "ok") != (repeated["status"] == "ok") or (original["status"] == repeated["status"] == "ok" and not equivalent(original, repeated, ordered=False)):
                    transforms["unchanged_sql_execution_disagreements"] += 1
            if c["sql"] != c["dail_voting_sql"]:
                transforms["modified_candidates"] += 1
                tokens = list(sqlparse.parse(c["sql"])[0].flatten()) if sqlparse.parse(c["sql"]) else []
                if any(t.value.lower() == "distinct" for t in tokens):
                    transforms["distinct_candidates"] += 1
                if any(op in c["sql"] for op in ("> =", "< =", "! =")):
                    transforms["spaced_operator_candidates"] += 1
                if "curdate" in c["sql"].lower():
                    transforms["curdate_candidates"] += 1
                if len(sqlparse.parse(c["sql"])) > 1:
                    transforms["multiple_statement_candidates"] += 1
    return {"model": name, "report_sha256": digest(report / "summary.json"), "comparisons": comparisons, "prefix_budgets": budgets, "per_database": by_db,
        "unavailable_case_primary_bounds_exploratory": {"unavailable": len(cases)-len(valid), "lower_delta_all_questions": (sum(score(r,"execution_bag")-score(r,"first") for r in valid)-(len(cases)-len(valid)))/len(cases), "upper_delta_all_questions": (sum(score(r,"execution_bag")-score(r,"first") for r in valid)+(len(cases)-len(valid)))/len(cases), "note": "Worst-case identification bounds assigning each unavailable paired difference -1 or +1; not confidence intervals and not imputed scores."},
        "constraint_screened": {"denominator": len(screened_cases), "correct": screened_counts, "collision_pairs": screened_pairs, "collision_questions": screened_questions, "changed_question_instances": screened_changed_instances},
        "full_changed_instance_collisions": {"pairs": full_changed_pairs, "questions": full_changed_questions},
        "constraint_screened_witness_plan": witness_plan, "collision_selection_relation_exploratory": dict(selected_relations), "false_reassurance_audit_exploratory": false_reassurance,
        "error_decomposition_exploratory": dict(error_decomposition), "winning_group_audit_exploratory": winning_groups,
        "generation_wall_seconds": generation["session_wall_seconds"], "generation_completion_sha256": digest(report / "generation_completion.json"), "dail_transform_counts": dict(transforms)}


def main():
    screen = read_json(ROOT / "reports/constraint_screen.json")
    result = {"protocol_lock_sha256": digest(ROOT / "docs/confirmation_lock.json"), "analysis_script_sha256": digest(Path(__file__)), "constraint_screen_sha256": digest(ROOT / "reports/constraint_screen.json"), "intervals": "4000 whole-database percentile bootstrap replicates, seed 2701; pointwise 95%, no multiplicity adjustment", "models": {name: analyze(name, screen) for name in ("qwen3b", "llama3b")}}
    write_json(ROOT / "reports/confirmation_analysis.json", result)
    for name, row in result["models"].items():
        print(name, row["comparisons"]["execution_bag_vs_first"], row["constraint_screened"])


if __name__ == "__main__":
    main()
