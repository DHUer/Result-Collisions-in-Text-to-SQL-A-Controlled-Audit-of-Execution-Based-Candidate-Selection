"""Create numbered tables and vector figures only from completed audit reports."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, read_jsonl, write_json
from collision_audit.reporting import summarize


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "svg.fonttype": "none", "svg.hashsalt": "edbt-collision-audit-v1"})
    out = ROOT / "manuscript/generated"
    out.mkdir(parents=True, exist_ok=True)
    reports = [ROOT / "reports/pilot_qwen3b_v2", ROOT / "reports/pilot_llama3b_v2"]
    summaries = []
    inputs = {}
    for directory in reports:
        saved = read_json(directory / "summary.json")
        recomputed = summarize(read_jsonl(directory / "case_audit.jsonl"), read_jsonl(directory / "candidate_audit.jsonl"), read_jsonl(directory / "generation_audit.jsonl"))
        for key, value in recomputed.items():
            if key == "sqlite_version":  # metadata of original execution, not this figure host
                continue
            if value != saved[key]:
                raise ValueError(f"Report does not reproduce: {directory.name}:{key}")
        summaries.append(saved)
        for name in ("summary.json", "case_audit.jsonl", "candidate_audit.jsonl", "generation_audit.jsonl"):
            inputs[str((directory / name).relative_to(ROOT))] = digest(directory / name)
    q, l = summaries
    methods = [("first", "First"), ("first_executable", "First executable"), ("exact_sql", "Exact SQL"), ("exact_sql_executable", "Exact SQL, executable"), ("execution_bag", "Execution bag"), ("execution_ordered", "Execution ordered"), ("execution_arity_blind", "Execution arity-blind"), ("execution_unique_sql", "Execution unique SQL")]
    macros = {"PilotQuestions": q["questions"], "PilotDatabases": q["databases"], "PilotCalls": q["candidate_calls"] + l["candidate_calls"], "QwenCollisionQuestions": q["questions_with_witnessed_collision"], "LlamaCollisionQuestions": l["questions_with_witnessed_collision"], "QwenPairs": q["distinct_sql_pairs_agreeing"], "LlamaPairs": l["distinct_sql_pairs_agreeing"], "QwenSeparated": q["distinct_sql_pairs_separated"], "LlamaSeparated": l["distinct_sql_pairs_separated"], "QwenUnique": q["unique_sql_total"], "LlamaUnique": l["unique_sql_total"]}
    for prefix, summary in (("Qwen", q), ("Llama", l)):
        macros[prefix + "InvalidGold"] = summary["invalid_gold_questions"]
        macros[prefix + "Seconds"] = f"{summary['generation_elapsed_seconds']:.1f}"
        macros[prefix + "Tokens"] = summary["completion_tokens"]
        for suffix, method in (("First", "first"), ("Vote", "execution_bag")):
            m = summary["metrics"][method]
            macros[prefix + suffix + "Original"] = f"{m['original_correct']}/{m['original_denominator']}"
            macros[prefix + suffix + "Suite"] = f"{m['suite_correct']}/{m['suite_denominator']}"
            macros[prefix + suffix + "False"] = f"{m['false_reassurance']}/{m['false_reassurance_denominator']}"
    (out / "numbers.tex").write_text("% Generated from measured reports; do not edit.\n" + "\n".join(r"\newcommand{\%s}{%s}" % (key, value) for key, value in macros.items()) + "\n")
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule", r"& \multicolumn{2}{c}{Qwen2.5-3B} & \multicolumn{2}{c}{Llama-3.2-3B} \\", r"Selector & Original & Suite & Original & Suite \\", r"\midrule"]
    for method, name in methods:
        cells = []
        for summary in summaries:
            m = summary["metrics"][method]
            cells.extend([f"{m['original_correct']}/{m['original_denominator']}", f"{m['suite_correct']}/{m['suite_denominator']}"])
        lines.append(name + " & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (out / "pilot_table.tex").write_text("\n".join(lines) + "\n")

    def save(fig, name):
        fig.savefig(out / (name + ".pdf"), bbox_inches="tight", metadata={"CreationDate": None, "ModDate": None})
        fig.savefig(out / (name + ".svg"), bbox_inches="tight", metadata={"Date": None})
        plt.close(fig)

    # Figure 1: a conceptual information-flow diagram, not a measured chart.
    fig, ax = plt.subplots(figsize=(7.05, 2.15))
    ax.set(xlim=(0, 10), ylim=(0, 3))
    ax.axis("off")
    boxes = [(0.1, 1.45, 2.0, "Question + schema\n5 local LLM samples"), (2.75, 1.45, 2.15, "Original database\nGold-free selection"), (5.65, 1.45, 1.65, "Freeze SQL\n+ ledger hashes"), (7.95, 1.45, 1.95, "Evaluation only\nGold + suite DBs")]
    for x, y, w, text in boxes:
        ax.add_patch(FancyBboxPatch((x, y), w, 0.95, boxstyle="round,pad=0.05", fc="#edf2f7", ec="#33536b", lw=1))
        ax.text(x + w / 2, y + .48, text, ha="center", va="center", fontsize=8)
    for start, end in ((2.13, 2.68), (4.93, 5.58), (7.33, 7.88)):
        ax.add_patch(FancyArrowPatch((start, 1.92), (end, 1.92), arrowstyle="-|>", mutation_scale=12, color="#33536b"))
    ax.plot([7.62, 7.62], [.1, 2.8], ls="--", color="#a64332", lw=1)
    ax.text(7.6, .14, "No evaluation feedback to generation or selection", ha="right", color="#a64332", fontsize=8.5)
    ax.text(4.25, .76, "All eight selectors share exactly the same candidate pool", ha="center", fontsize=9)
    save(fig, "pipeline")

    display = ["first", "first_executable", "exact_sql_executable", "execution_bag", "execution_unique_sql"]
    names = ["First", "First executable", "Exact SQL (valid)", "Execution bag", "Unique-SQL vote"]
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.65), sharex=True, sharey=True)
    for ax, summary, title in zip(axes, summaries, ["Qwen2.5-3B Q8_0", "Llama-3.2-3B Q8_0"]):
        for shift, metric, color, label in [(-.18, "original_correct", "#88b3c9", "Original DB"), (.18, "suite_correct", "#285979", "Suite")]:
            values = [summary["metrics"][m][metric] for m in display]
            bars = ax.barh([i + shift for i in range(len(display))], values, height=.33, color=color, label=label)
            ax.bar_label(bars, fontsize=8, padding=2)
        ax.set_title(title, fontsize=10)
        ax.set_yticks(range(len(display)), names)
        ax.set_xlim(0, 26)
        ax.set_xticks([0, 6, 12, 18, 24])
        ax.set_xlabel("Correct selected queries (counts)")
        ax.grid(axis="x", alpha=.15)
    axes[0].invert_yaxis()
    handles, legend_labels = axes[1].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", ncol=2, fontsize=8, frameon=False, bbox_to_anchor=(.62, 1.07))
    fig.tight_layout()
    save(fig, "pilot_selection")

    categories = ["empty", "scalar_zero", "scalar_null", "other", "invalid"]
    fig, ax = plt.subplots(figsize=(3.4, 2.2))
    for offset, summary, color, label in [(-.19, q, "#285979", "Qwen"), (.19, l, "#af613b", "Llama")]:
        values = [summary["candidate_result_kinds"].get(c, 0) for c in categories]
        bars = ax.bar([i + offset for i in range(5)], values, width=.36, color=color, label=label)
        ax.bar_label(bars, fontsize=8, padding=2)
    ax.set_xticks(range(5), ["Empty", "Zero", "NULL", "Other", "Invalid"], fontsize=8)
    ax.set_ylabel("Generated candidates")
    ax.set_ylim(0, 110)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    save(fig, "pilot_result_types")
    write_json(out / "figure_manifest.json", {"inputs": inputs, "renderer_sha256": digest(Path(__file__)), "matplotlib": matplotlib.__version__, "note": "pipeline is conceptual; other figures and table use v2 measured pilot reports only", "outputs": {p.name: digest(p) for p in sorted(out.iterdir()) if p.suffix in (".pdf", ".svg", ".tex") and p.stem in ("numbers", "pilot_table", "pipeline", "pilot_selection", "pilot_result_types")}})
    print("Generated measured pilot table, numbers, and three vector figures")


if __name__ == "__main__":
    main()
