"""Record a local confirmation freeze, without claiming preregistration."""
import argparse
import datetime
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    if args.output.exists():
        p.error("A freeze is immutable; choose a new output path")
    revision = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True)
    manifest = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "protocol_sha256": digest(ROOT / "docs/PROTOCOL.md"), "split_sha256": digest(ROOT / "docs/split_manifest.json"), "config_sha256": digest(ROOT / "configs/study.json"), "git_revision": revision.stdout.strip(), "code_sha256": {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / "src").rglob("*.py"))}, "note": "Local freeze only. Review readiness gates separately; this is not preregistration or publication certification."}
    write_json(args.output, manifest)
    snapshot = args.output.with_suffix(".zip")
    with zipfile.ZipFile(snapshot, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in [ROOT / "docs/PROTOCOL.md", ROOT / "configs/study.json", ROOT / "docs/split_manifest.json", args.output.resolve()] + sorted((ROOT / "src").rglob("*.py")):
            archive.write(path, str(path.relative_to(ROOT)))
    # Preserve the pre-confirmation working manuscript, including generated assets.
    with zipfile.ZipFile(ROOT / "artifacts/pre_confirmation_manuscript.zip", "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / "manuscript").rglob("*")):
            if path.is_file() and path.suffix in (".tex", ".bib", ".pdf", ".json"):
                archive.write(path, str(path.relative_to(ROOT)))
    print(args.output)


if __name__ == "__main__":
    main()
