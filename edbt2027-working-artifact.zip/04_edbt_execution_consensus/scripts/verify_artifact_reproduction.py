"""Verify the packaged code/reports in a fresh directory without weights/data."""
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, write_json


def main():
    archive = ROOT / "artifacts/edbt2027-working-artifact.zip"
    with tempfile.TemporaryDirectory(prefix="edbt-artifact-check-") as tmp:
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                assert not Path(name).is_absolute() and ".." not in Path(name).parts
            z.extractall(tmp)
        restored = Path(tmp) / "04_edbt_execution_consensus"
        manifest = json.loads((restored / "FILE_MANIFEST.json").read_text())
        for name, expected in manifest.items():
            assert digest(restored / name) == expected, name
        assert not (restored / "data").exists() and not (restored / "runs").exists()
        env = dict(os.environ, PYTHONPATH=str(restored / "src"), PYTHONWARNINGS="ignore::SyntaxWarning")
        tested = subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-q"],cwd=restored,env=env,check=True,capture_output=True,text=True)
        print(tested.stderr,flush=True)
        test_count = int(re.search(r"Ran (\d+) tests", tested.stderr).group(1))
        inputs = [restored / "reports/confirmation_analysis.json", restored / "reports/extension_analysis.json"]
        inputs += [p for p in (restored / "manuscript/generated").iterdir() if p.suffix in (".tex", ".pdf", ".svg")]
        before = {str(p.relative_to(restored)):digest(p) for p in inputs}
        for script in ("analyze_confirmation.py", "analyze_extension.py", "render_paper_assets.py", "render_confirmation.py"):
            subprocess.run([sys.executable, str(restored / "scripts" / script)],cwd=restored,env=env,check=True,stdout=subprocess.DEVNULL)
        for name, expected in before.items():
            assert digest(restored / name) == expected, ("regeneration differs",name)
        result = {"archive_sha256":digest(archive), "verified_payload_manifest_sha256": digest(restored / "FILE_MANIFEST.json"), "files_hash_checked":len(manifest), "unit_tests_passed":test_count, "regenerated_files_identical":len(before), "raw_data_or_models_required":False, "checks":["safe archive paths", "all payload SHA-256 checks", "unit tests in fresh extraction", "report-only paired analysis", "byte-identical generated tables and PDF/SVG figures"], "note":"Existing Python dependencies are reused; no new model calls or database downloads. This verification report stays outside the ZIP to avoid a self-referential archive hash."}
    write_json(ROOT / "reports/artifact_reproduction.json", result)
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
