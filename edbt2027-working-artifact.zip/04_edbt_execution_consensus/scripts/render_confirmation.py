"""Render tables/vector figures from measured, verified confirmation reports."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, write_json

METHODS = [("first", "First"), ("first_executable", "First executable"), ("exact_sql", "Exact SQL"), ("exact_sql_executable", "Exact SQL, executable"), ("execution_bag", "Typed-bag vote"), ("execution_ordered", "Ordered vote"), ("execution_arity_blind", "Arity-blind vote"), ("execution_unique_sql", "Unique-SQL vote"), ("execution_official", "Comparator vote"), ("dail_sc", "DAIL-SC aggregation")]


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "svg.fonttype": "none", "svg.hashsalt": "edbt-collision-audit-v1"})
    out = ROOT / "manuscript/generated"
    analysis = read_json(ROOT / "reports/confirmation_analysis.json")
    sensitivity = read_json(ROOT / "reports/timeout_sensitivity.json")
    verification = read_json(ROOT / "reports/confirmation_verification.json")
    assert all(m["all_passed"] for m in verification["models"].values())
    names = ("qwen3b", "llama3b")
    summaries = {name: read_json(ROOT / f"reports/confirmation_{name}/summary.json") for name in names}
    for name in names:
        summary = summaries[name]
        lines = [f"# Measured confirmation: {name}", "", "866 questions, 16 databases, 4,330 generated samples. This is a custom Spider-dev partition, not a full official leaderboard score.", "", "| Selector | Original pass | Suite pass | False reassurance |", "|---|---:|---:|---:|"]
        for method,label in METHODS:
            m=summary["metrics"][method]
            lines.append(f"| {label} | {m['original_correct']}/{m['original_denominator']} | {m['suite_correct']}/{m['suite_denominator']} | {m['false_reassurance']}/{m['false_reassurance_denominator']} |")
        lines += ["", "Paired intervals resample the 16 whole database clusters (4,000 replicates, seed 2701); they are pointwise, not multiplicity-adjusted. Two gold-reference row-limit failures are unavailable for every method.", "", "See [the combined evidence report](../CONFIRMATION_EVIDENCE.md) for interpretation, constraint/resource checks, protocol amendments and limitations. DAIL-SC is the released aggregation stage, not an end-to-end DAIL-SQL replication. Human review and author/release details remain outstanding."]
        (ROOT / f"reports/confirmation_{name}/RESULTS.md").write_text("\n".join(lines)+"\n")
    macros = {"CQuestions": 866, "CDatabases": 16, "CCalls": 8660}
    for name, prefix in zip(names, ("CQwen", "CLlama")):
        s, a = summaries[name], analysis["models"][name]
        macros.update({prefix + "Valid": s["valid_suite_questions"], prefix + "GoldFailures": s["invalid_gold_questions"], prefix + "Collisions": s["questions_with_witnessed_collision"], prefix + "Pairs": s["distinct_sql_pairs_agreeing"], prefix + "Separated": s["distinct_sql_pairs_separated"], prefix + "OriginalAgreements": s["questions_with_distinct_sql_agreement"], prefix + "ArityChanges": s["arity_blind_selection_changes"], prefix + "Tokens": s["completion_tokens"], prefix + "Seconds": f"{a['generation_wall_seconds']:.1f}", prefix + "RequestsFailed": s["request_failures"], prefix + "Truncated": s["truncated_responses"], prefix + "InstanceEvaluations": s["suite_instance_executions"], prefix + "Oracle": s["oracle_suite_pass_at_k_count"], prefix + "ScreenedCollisions": a["constraint_screened"]["collision_questions"], prefix + "ScreenedPairs": a["constraint_screened"]["collision_pairs"]})
        for method, suffix in (("first", "First"), ("first_executable", "Executable"), ("execution_bag", "Bag"), ("dail_sc", "Dail"), ("execution_official", "Comparator")):
            m = s["metrics"][method]
            macros[prefix + suffix + "Suite"] = f"{m['suite_correct']}/{m['suite_denominator']}"
            macros[prefix + suffix + "Original"] = f"{m['original_correct']}/{m['original_denominator']}"
            macros[prefix + suffix + "False"] = f"{m['false_reassurance']}/{m['false_reassurance_denominator']}"
        for contrast, suffix in (("execution_bag_vs_first", "Primary"), ("first_executable_vs_first", "Filter"), ("execution_bag_vs_first_executable", "Residual"), ("dail_sc_vs_execution_official", "Preprocess")):
            c = a["comparisons"][contrast]
            macros[prefix + suffix + "Delta"] = f"{100*c['estimate']:+.1f}"
            macros[prefix + suffix + "Interval"] = f"[{100*c['ci95'][0]:+.1f}, {100*c['ci95'][1]:+.1f}]"
            macros[prefix + suffix + "Wins"] = c["wins"]
            macros[prefix + suffix + "Losses"] = c["losses"]
        macros[prefix + "FalseOther"] = s["execution_vote_strata"]["other"]["false_reassurance"]
        macros[prefix + "FalseTotal"] = s["metrics"]["execution_bag"]["false_reassurance"]
    (out / "confirmation_numbers.tex").write_text("% Generated measured confirmation values; do not edit.\n" + "\n".join(r"\newcommand{\%s}{%s}" % (k,v) for k,v in macros.items()) + "\n")
    lines = [r"\begin{tabular}{lrrrrrr}", r"\toprule", r"& \multicolumn{3}{c}{Qwen2.5-3B} & \multicolumn{3}{c}{Llama-3.2-3B} \\", r"Selector & Original & Suite & False reassurance & Original & Suite & False reassurance \\", r"\midrule"]
    for method, label in METHODS:
        cells = []
        for name in names:
            m = summaries[name]["metrics"][method]
            cells.extend([f"{m['original_correct']}/{m['original_denominator']}", f"{m['suite_correct']}/{m['suite_denominator']}", f"{m['false_reassurance']}/{m['false_reassurance_denominator']}"])
        lines.append(label + " & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (out / "confirmation_table.tex").write_text("\n".join(lines) + "\n")
    contrasts = [("execution_bag_vs_first", "Bag minus first (primary)"), ("first_executable_vs_first", "Filtering: executable minus first"), ("execution_bag_vs_first_executable", "Voting: bag minus executable"), ("dail_sc_vs_execution_official", "Preprocessing: DAIL minus comparator"), ("execution_unique_sql_vs_execution_bag", "Unique SQL minus bag"), ("execution_official_vs_execution_bag", "Comparator minus bag")]
    lines = [r"\begin{tabular}{lrr}", r"\toprule", r"Paired suite-pass contrast & Qwen: pp [95\% CI] & Llama: pp [95\% CI] \\", r"\midrule"]
    for key, label in contrasts:
        cells = []
        for name in names:
            c = analysis["models"][name]["comparisons"][key]
            cells.append(f"{100*c['estimate']:+.1f} [{100*c['ci95'][0]:+.1f}, {100*c['ci95'][1]:+.1f}]")
        lines.append(label + " & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (out / "confirmation_contrasts.tex").write_text("\n".join(lines) + "\n")
    lines = [r"\begin{tabular}{lrr}", r"\toprule", r"Diagnostic & Qwen & Llama \\", r"\midrule"]
    for key, label in [("candidate_calls", "Generated samples"), ("request_failures", "Request failures"), ("truncated_responses", "Token-cap truncations"), ("unique_sql_total", "Distinct SQL strings (summed per pool)"), ("questions_with_distinct_sql_agreement", "Questions with eligible agreeing pairs"), ("questions_with_witnessed_collision", "Questions with witnessed collisions"), ("distinct_sql_pairs_separated", "Separated distinct-SQL pairs"), ("distinct_sql_pairs_agreeing", "Eligible agreeing distinct-SQL pairs"), ("arity_blind_selection_changes", "Arity-blind selection changes"), ("completion_tokens", "Completion tokens"), ("suite_instance_executions", "Question--suite-instance evaluations")]:
        lines.append(label + " & " + " & ".join(str(summaries[n][key]) for n in names) + r" \\")
    lines.append("Generation session wall time (seconds) & " + " & ".join(f"{analysis['models'][n]['generation_wall_seconds']:.1f}" for n in names) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (out / "confirmation_diagnostics.tex").write_text("\n".join(lines) + "\n")
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule", r"& \multicolumn{2}{c}{Qwen} & \multicolumn{2}{c}{Llama} \\", r"154-question panel & 2 seconds & 10 seconds & 2 seconds & 10 seconds \\", r"\midrule"]
    lines.append("Gold-available questions & " + " & ".join(f"{sensitivity['models'][n][key]}/{sensitivity['panel_size']}" for n in names for key in ("primary_available","longer_available")) + r" \\")
    for method,label in [("first","First suite pass"),("first_executable","First executable suite pass"),("execution_bag","Typed-bag suite pass"),("dail_sc","DAIL-SC suite pass")]:
        values=[]
        for n in names:
            s=sensitivity["models"][n]["methods"][method]
            values.extend([f"{s[key]}/{s['common_denominator']}" for key in ("primary_correct_common","longer_correct_common")])
        lines.append(label + " & " + " & ".join(values) + r" \\")
    lines += [r"\bottomrule",r"\end{tabular}"]
    (out / "confirmation_timeout.tex").write_text("\n".join(lines) + "\n")
    lines = [r"\begin{tabular}{lrr}", r"\toprule", r"Retrospective outcome category & Qwen & Llama \\", r"\midrule"]
    for key,label in [("correct_selection","Selected query passes"),("no_correct_candidate","No correct query in pool"),("correct_candidate_in_winning_group","Wrong selection; correct query in winning group"),("correct_candidates_only_outside_winning_group","Wrong selection; correct queries only outside winning group")]:
        lines.append(label + " & " + " & ".join(str(analysis["models"][n]["error_decomposition_exploratory"].get(key,0)) for n in names) + r" \\")
    lines += [r"\bottomrule",r"\end{tabular}"]
    (out / "confirmation_decomposition.tex").write_text("\n".join(lines) + "\n")
    def save(fig, name):
        fig.savefig(out / (name + ".pdf"), bbox_inches="tight", metadata={"CreationDate": None, "ModDate": None})
        fig.savefig(out / (name + ".svg"), bbox_inches="tight", metadata={"Date": None})
        plt.close(fig)
    # Conceptual information-flow figure; no data are represented by its geometry.
    fig, ax = plt.subplots(figsize=(7.05, 1.55))
    ax.set(xlim=(0,10), ylim=(0,2)); ax.axis("off")
    boxes = [(0.1, 2.0, "Question + schema\n5 local LLM samples"), (2.75, 2.15, "Original database\n10 gold-free selectors"), (5.65, 1.65, "Freeze choices\n+ ledger hashes"), (7.95, 1.95, "Evaluation only\nGold + suite DBs")]
    for x,w,label in boxes:
        ax.add_patch(FancyBboxPatch((x,.8),w,.8,boxstyle="round,pad=0.04",fc="#edf2f7",ec="#33536b"))
        ax.text(x+w/2,1.2,label,ha="center",va="center",fontsize=8)
    for a,b in ((2.13,2.68),(4.93,5.58),(7.33,7.88)):
        ax.add_patch(FancyArrowPatch((a,1.2),(b,1.2),arrowstyle="-|>",mutation_scale=12,color="#33536b"))
    ax.plot([7.62,7.62],[.4,1.9],ls="--",color="#a64332")
    ax.text(5,.24,"Identical candidate pools; no evaluation feedback to generation or selection",ha="center",fontsize=9)
    save(fig,"confirmation_pipeline")
    # Smallest useful effect visualization: paired effects and clustered uncertainty.
    fig, axes = plt.subplots(1,2,figsize=(7.1,2.85),sharex=True,sharey=True)
    display = contrasts[:4]
    for ax,name,title,color in zip(axes,names,["Qwen2.5-3B Q8_0","Llama-3.2-3B Q8_0"],["#285979","#af613b"]):
        for y,(key,_) in enumerate(display):
            c=analysis["models"][name]["comparisons"][key]
            estimate=100*c["estimate"]; low,high=[100*v for v in c["ci95"]]
            ax.plot([low,high],[y,y],color=color,lw=2)
            ax.plot(estimate,y,"o",color=color)
        ax.axvline(0,color=".6",lw=.8,ls="--")
        ax.set_title(title,fontsize=10)
        ax.set_yticks(range(4),["Bag − first","Executable − first","Bag − executable","DAIL − comparator"])
        ax.set_xlabel("Paired suite-pass difference (pp)")
        ax.grid(axis="x",alpha=.15)
    axes[0].invert_yaxis(); fig.tight_layout(); save(fig,"confirmation_effects")
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.8),sharey=True)
    for ax,name,title in zip(axes,names,["Qwen2.5-3B Q8_0","Llama-3.2-3B Q8_0"]):
        b=analysis["models"][name]["prefix_budgets"]
        for method,label,color,style in [("first_executable","First executable","#929292","--"),("execution_bag","Typed-bag vote","#285979","-"),("dail_sc","DAIL-SC aggregation","#af613b","-."),("oracle","Oracle pool bound","#52764b",":")]:
            values=[100*(b[str(k)]["oracle_correct"] if method=="oracle" else b[str(k)]["correct"][method])/b[str(k)]["denominator"] for k in (1,3,5)]
            ax.plot([1,3,5],values,marker="o",ls=style,color=color,label=label,ms=4)
        ax.set(xticks=[1,3,5],xlabel="Candidates available (fixed-pool prefix)")
        ax.set_title(title,fontsize=10); ax.grid(alpha=.15)
    axes[0].set_ylabel("Suite pass (%)")
    h,l=axes[1].get_legend_handles_labels(); fig.legend(h,l,ncol=2,loc="upper center",bbox_to_anchor=(.53,1.17),frameon=False,fontsize=8)
    fig.tight_layout(); save(fig,"confirmation_budget")
    dbs=sorted(analysis["models"][names[0]]["per_database"])
    fig,axes=plt.subplots(1,2,figsize=(7.1,4.3),sharex=True,sharey=True)
    for ax,name,title in zip(axes,names,["Qwen: bag − first","Llama: bag − first"]):
        rows=[analysis["models"][name]["per_database"][db] for db in dbs]
        values=[100*(r["correct"]["execution_bag"]-r["correct"]["first"])/r["valid"] if r["valid"] else 0 for r in rows]
        ax.barh(range(len(dbs)),values,color=["#285979" if v>=0 else "#af613b" for v in values],height=.65)
        ax.axvline(0,color=".5",lw=.8)
        ax.set_yticks(range(len(dbs)),[db.replace("_"," ") for db in dbs],fontsize=8)
        ax.set_title(title,fontsize=10);ax.set_xlabel("Within-database change (pp)");ax.grid(axis="x",alpha=.15)
    axes[0].invert_yaxis();fig.tight_layout();save(fig,"confirmation_databases")
    inputs=[ROOT/"reports/confirmation_analysis.json",ROOT/"reports/timeout_sensitivity.json",ROOT/"reports/confirmation_verification.json"]+[ROOT/f"reports/confirmation_{n}/summary.json" for n in names]
    write_json(out/"confirmation_figure_manifest.json",{"inputs":{str(p.relative_to(ROOT)):digest(p) for p in inputs},"renderer_sha256":digest(Path(__file__)),"matplotlib":matplotlib.__version__,"outputs":{p.name:digest(p) for p in out.glob("confirmation_*") if p.suffix in (".pdf",".svg",".tex")},"note":"Only the pipeline is conceptual. Other figures/tables are measured confirmation evidence; prefix curves are dependent and have no independent-run intervals."})
    print("Rendered confirmation tables, numbers, and four vector figures")


if __name__ == "__main__":
    main()
