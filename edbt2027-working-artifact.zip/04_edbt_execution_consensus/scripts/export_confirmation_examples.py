"""Post-hoc illustrations, hash-selected within an explicitly named stratum."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, read_jsonl, stable_hash, write_json


def main():
    analysis = read_json(ROOT / "reports/confirmation_analysis.json")
    inputs = {r["id"]: r for r in read_jsonl(ROOT / "data/processed/confirmation.inputs.jsonl")}
    labels = {r["id"]: r for r in read_jsonl(ROOT / "data/processed/confirmation.labels.jsonl")}
    result = {"classification": "post-hoc illustrations, not a mechanism-frequency estimate", "salt": "confirmation-case-example-v1", "stratum": "correct_candidate_in_winning_group", "script_sha256": digest(Path(__file__)), "models": {}}
    for name in ("qwen3b", "llama3b"):
        selected = {r["id"]: r for r in read_jsonl(ROOT / f"reports/confirmation_{name}/candidate_audit.jsonl")}
        evaluated = {r["id"]: r for r in read_jsonl(ROOT / f"reports/confirmation_{name}/case_audit.jsonl")}
        candidates = [r for r in analysis["models"][name]["winning_group_audit_exploratory"] if r["category"] == result["stratum"]]
        chosen = min(candidates, key=lambda r: stable_hash([result["salt"],r["id"]]))
        i = chosen["id"]
        result["models"][name] = {"id":i, "db_id":chosen["db_id"], "question":inputs[i]["question"], "schema":inputs[i]["schema"], "gold_sql":labels[i]["gold_sql"], "selected":selected[i], "evaluation":evaluated[i]}
    write_json(ROOT / "reports/confirmation_examples.json", result)
    print({n:r["id"] for n,r in result["models"].items()})


if __name__ == "__main__":
    main()
