"""Post-confirmation extension: the frozen protocol, unchanged, on a larger third-family model.

The 866 questions were already analyzed for the two 3B models, so this is a
replication on a seen split, not a fresh holdout. Reuses analyze_confirmation.analyze.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from collision_audit.common import digest, read_json, write_json
from analyze_confirmation import analyze

NAME, LABEL = "gemma12b", "Gemma-4-12B"


def main():
    screen = read_json(ROOT / "reports/constraint_screen.json")
    a = analyze(NAME, screen, prefix="extension")
    s = read_json(ROOT / f"reports/extension_{NAME}/summary.json")
    write_json(ROOT / "reports/extension_analysis.json", {"protocol_lock_sha256": digest(ROOT / "docs/confirmation_lock.json"), "analysis_script_sha256": digest(Path(__file__)), "note": "Unchanged frozen protocol; server started with --reasoning-budget 0. Seen split, not a fresh holdout.", "models": {NAME: a}})
    m = s["metrics"]
    c = a["comparisons"]
    e = a["error_decomposition_exploratory"]
    frac = lambda k: f"{m[k]['suite_correct']}/{m[k]['suite_denominator']}"
    macros = {
        "GValid": s["valid_suite_questions"], "GGoldFailures": s["invalid_gold_questions"],
        "GRequestsFailed": s["request_failures"], "GTruncated": s["truncated_responses"],
        "GCollisions": s["questions_with_witnessed_collision"], "GPairs": s["distinct_sql_pairs_agreeing"],
        "GSeparated": s["distinct_sql_pairs_separated"], "GOracle": s["oracle_suite_pass_at_k_count"],
        "GSeconds": f"{a['generation_wall_seconds']:.1f}", "GTokens": s["completion_tokens"],
        "GFirstSuite": frac("first"), "GExecutableSuite": frac("first_executable"), "GBagSuite": frac("execution_bag"),
        "GDailSuite": frac("dail_sc"), "GBagFalse": f"{m['execution_bag']['false_reassurance']}/{m['execution_bag']['false_reassurance_denominator']}",
        "GNoCorrect": e.get("no_correct_candidate", 0), "GInGroup": e.get("correct_candidate_in_winning_group", 0),
        "GOutGroup": e.get("correct_candidates_only_outside_winning_group", 0),
        "GArityChanges": s["arity_blind_selection_changes"],
    }
    for key, suffix in (("execution_bag_vs_first", "Primary"), ("first_executable_vs_first", "Filter"), ("execution_bag_vs_first_executable", "Residual"), ("dail_sc_vs_execution_official", "Preprocess")):
        macros["G" + suffix + "Delta"] = f"{100*c[key]['estimate']:+.1f}"
        macros["G" + suffix + "Interval"] = f"[{100*c[key]['ci95'][0]:+.1f}, {100*c[key]['ci95'][1]:+.1f}]"
        macros["G" + suffix + "Wins"], macros["G" + suffix + "Losses"] = c[key]["wins"], c[key]["losses"]
    net = c["execution_bag_vs_first"]["wins"] - c["execution_bag_vs_first"]["losses"]
    filt = c["first_executable_vs_first"]["wins"] - c["first_executable_vs_first"]["losses"]
    macros["GFilterShare"] = f"{100*filt/net:.0f}" if net > 0 else "n/a"
    out = ROOT / "manuscript/generated/extension_numbers.tex"
    out.write_text("% Generated from reports/extension_analysis.json; do not edit.\n" + "\n".join(r"\newcommand{\%s}{%s}" % kv for kv in macros.items()) + "\n")
    print(macros)


if __name__ == "__main__":
    main()
