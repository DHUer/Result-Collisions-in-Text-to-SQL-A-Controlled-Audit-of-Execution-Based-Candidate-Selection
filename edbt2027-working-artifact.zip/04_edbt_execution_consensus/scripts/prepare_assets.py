"""Download public assets, record hashes, and safely unpack inert data/template files.

Only the normal Google Drive large-file confirmation form is followed. No login,
access control, or bot challenge is bypassed. Existing archives are never replaced.
"""
import argparse
import hashlib
import json
import shutil
import stat
import urllib.parse
import urllib.request
import zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "e97acc546ecbee8fa27fa8dbf025ef61493a876c"
ASSETS = {
    "spider": ("1403EGqzIDoHMdQF4c9Bkyl7dZLZ5Wt6J", "data/raw/spider.zip", "data/raw/spider"),
    "testsuite": ("1mkCx2GOFIqNesD4y8TDAO1yX1QZORP5w", "data/raw/testsuite.zip", "data/raw/testsuite"),
    "template": ("1dtNEVPLPNTlKm1_agOxlHWuQK-Szd8Lo", "vendor/edbt2027/template.zip", "vendor/edbt2027"),
}


class DownloadForm(HTMLParser):
    def __init__(self):
        super().__init__()
        self.action = None
        self.fields = {}
        self.inside = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "form" and attrs.get("id") == "download-form":
            self.action = attrs.get("action")
            self.inside = True
        if self.inside and tag == "input" and attrs.get("type") == "hidden":
            self.fields[attrs["name"]] = attrs.get("value", "")

    def handle_endtag(self, tag):
        if tag == "form":
            self.inside = False


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url, dest, cap=2_000_000_000):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        return
    response = urllib.request.urlopen(url, timeout=90)
    if "text/html" in response.headers.get("Content-Type", ""):
        html = response.read(1_000_000).decode()
        response.close()
        form = DownloadForm()
        form.feed(html)
        if "can't scan this file for viruses" not in html or form.action != "https://drive.usercontent.google.com/download":
            raise RuntimeError("Unexpected download page; not following it")
        response = urllib.request.urlopen(form.action + "?" + urllib.parse.urlencode(form.fields), timeout=90)
        if "text/html" in response.headers.get("Content-Type", ""):
            raise RuntimeError("Download remains HTML; inspect the provider manually")
    partial = dest.with_suffix(dest.suffix + ".partial")
    total = 0
    with response, partial.open("wb") as f:
        while chunk := response.read(1024 * 1024):
            total += len(chunk)
            if total > cap:
                raise RuntimeError("Download exceeds size limit")
            f.write(chunk)
    partial.replace(dest)


def safe_extract(archive, directory, cap=15_000_000_000):
    directory.mkdir(parents=True, exist_ok=True)
    root = directory.resolve()
    with zipfile.ZipFile(archive) as z:
        if sum(i.file_size for i in z.infolist()) > cap:
            raise ValueError("Archive exceeds expanded size limit")
        for item in z.infolist():
            target = (root / item.filename).resolve()
            if not target.is_relative_to(root) or stat.S_ISLNK(item.external_attr >> 16):
                raise ValueError("Unsafe archive member: " + item.filename)
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            # Archives are data, not runnable programs. Ignore OS metadata.
            if "__MACOSX" in target.parts or target.name.startswith("._"):
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                if target.stat().st_size != item.file_size:
                    raise ValueError("Existing asset has different length: " + str(target))
                with z.open(item) as src:
                    if hashlib.sha256(src.read()).hexdigest() != sha256(target):
                        raise ValueError("Existing asset content differs: " + str(target))
                continue
            with z.open(item) as src, target.open("xb") as dst:
                shutil.copyfileobj(src, dst)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("assets", nargs="*", choices=list(ASSETS), default=list(ASSETS))
    args = parser.parse_args()
    manifest_path = ROOT / "docs/asset_manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    for name in args.assets:
        file_id, local, extracted = ASSETS[name]
        url = "https://drive.google.com/uc?export=download&id=" + file_id
        archive = ROOT / local
        print("Preparing", name, flush=True)
        download(url, archive)
        if not zipfile.is_zipfile(archive):
            raise ValueError("Not a ZIP archive: " + str(archive))
        checksum = sha256(archive)
        if name in manifest and manifest[name]["sha256"] != checksum:
            raise ValueError("Asset drift: " + name)
        safe_extract(archive, ROOT / extracted)
        manifest[name] = {"url": url, "sha256": checksum, "bytes": archive.stat().st_size, "extracted": extracted}
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    # Retain the full upstream comparator source, but never run its SQL executor.
    for name in ("exec_eval.py", "LICENSE", "README.md"):
        url = f"https://raw.githubusercontent.com/taoyds/test-suite-sql-eval/{COMMIT}/{name}"
        path = ROOT / "vendor/test_suite" / name
        download(url, path, cap=1_000_000)
        key = "test_suite/" + name
        checksum = sha256(path)
        if key in manifest and manifest[key]["sha256"] != checksum:
            raise ValueError("Vendor source drift")
        manifest[key] = {"url": url, "sha256": checksum, "commit": COMMIT}
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

