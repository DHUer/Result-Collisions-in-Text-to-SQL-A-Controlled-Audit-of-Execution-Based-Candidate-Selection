"""Screen public suite data against a limited set of ORIGINAL declared constraints.

This is not full schema/business-rule validation. No model outputs or gold SQL
are consumed. Trusted benchmark metadata is quoted as SQL identifiers.
"""
import collections
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, write_json
from collision_audit.data import original_database, suite_databases


def ident(value):
    return '"' + value.replace('"', '""') + '"'


def connect(path):
    conn = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    conn.execute("PRAGMA query_only=ON")
    return conn


def checks_for(original):
    with connect(original) as conn:
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        columns = {table: list(conn.execute(f"PRAGMA table_info({ident(table)})")) for table in tables}
        checks = []
        for table in tables:
            pk = [r[1] for r in sorted(columns[table], key=lambda r: r[5]) if r[5]]
            if pk:
                nonnull = " AND ".join(f"{ident(c)} IS NOT NULL" for c in pk)
                keys = ", ".join(map(ident, pk))
                checks.append({"table": table, "kind": "primary_key_duplicates", "columns": pk,
                    "sql": f"SELECT COUNT(*) FROM (SELECT {keys} FROM {ident(table)} WHERE {nonnull} GROUP BY {keys} HAVING COUNT(*) > 1)"})
            for col in columns[table]:
                if col[3]:
                    checks.append({"table": table, "kind": "declared_not_null", "columns": [col[1]],
                        "sql": f"SELECT COUNT(*) FROM {ident(table)} WHERE {ident(col[1])} IS NULL"})
            fks = collections.defaultdict(list)
            for row in conn.execute(f"PRAGMA foreign_key_list({ident(table)})"):
                fks[row[0]].append(row)
            for number, rows in sorted(fks.items()):
                rows.sort(key=lambda r: r[1])
                target = rows[0][2]
                target_pk = [r[1] for r in sorted(columns.get(target, []), key=lambda r: r[5]) if r[5]]
                child = [r[3] for r in rows]
                parent = [r[4] or (target_pk[i] if i < len(target_pk) else None) for i, r in enumerate(rows)]
                check = {"table": table, "kind": "foreign_key_orphans", "foreign_key_id": number, "columns": child, "parent_table": target, "parent_columns": parent}
                if None in parent:
                    check["unsupported"] = "Cannot resolve implicit parent key"
                else:
                    nonnull = " AND ".join(f"c.{ident(c)} IS NOT NULL" for c in child)
                    equality = " AND ".join(f"p.{ident(p)} = c.{ident(c)}" for c, p in zip(child, parent))
                    check["sql"] = f"SELECT COUNT(*) FROM {ident(table)} AS c WHERE {nonnull} AND NOT EXISTS (SELECT 1 FROM {ident(target)} AS p WHERE {equality})"
                checks.append(check)
    return {"required_columns": {t: [r[1] for r in cs] for t, cs in columns.items()}, "checks": checks}


def screen(path, spec):
    records = []
    with connect(path) as conn:
        for table, columns in spec["required_columns"].items():
            present = {r[1] for r in conn.execute(f"PRAGMA table_info({ident(table)})")}
            missing = sorted(set(columns) - present)
            if missing:
                records.append({"kind": "schema_columns", "table": table, "status": "unknown", "missing": missing})
        for number, check in enumerate(spec["checks"]):
            row = {"check": number, "kind": check["kind"], "table": check["table"]}
            if "unsupported" in check:
                row.update(status="unknown", error=check["unsupported"])
            else:
                deadline = time.monotonic() + 10
                conn.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
                try:
                    count = conn.execute(check["sql"]).fetchone()[0]
                    row.update(status="pass" if count == 0 else "violation", count=count)
                except sqlite3.Error as exc:
                    row.update(status="unknown", error=str(exc))
            records.append(row)
    return {"sha256": digest(path), "passed_screen": bool(spec["checks"]) and all(r["status"] == "pass" for r in records), "checks": records}


def main():
    split = read_json(ROOT / "docs/split_manifest.json")
    result = {"script_sha256": digest(Path(__file__)), "sqlite_version": sqlite3.sqlite_version,
        "scope": "Original declared PK uniqueness among non-NULL keys, explicit NOT NULL, and FK orphan checks; all required original columns must be present. Does not certify types, CHECK/UNIQUE constraints, triggers, collations or business semantics.", "databases": {}}
    for db in split["confirmation_databases"]:
        original = original_database(db)
        spec = checks_for(original)
        entry = {"specification": spec, "original": screen(original, spec), "instances": {p.name: screen(p, spec) for p in suite_databases(db)}}
        result["databases"][db] = entry
        print(f"{db}: {sum(v['passed_screen'] for v in entry['instances'].values())}/{len(entry['instances'])} pass declared-constraint screen", flush=True)
    write_json(ROOT / "reports/constraint_screen.json", result)


if __name__ == "__main__":
    main()
