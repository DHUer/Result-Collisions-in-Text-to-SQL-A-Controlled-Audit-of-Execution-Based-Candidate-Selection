"""Build the working draft using the unchanged official EDBT 2027 template."""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tectonic", default="tectonic")
    args = parser.parse_args()
    executable = shutil.which(args.tectonic)
    if not executable:
        raise FileNotFoundError(f"Tectonic executable not found: {args.tectonic}")
    executable = str(Path(executable).resolve())
    stage = ROOT / "build/paper"
    stage.mkdir(parents=True, exist_ok=True)
    sources = sorted((ROOT / "manuscript").glob("*.tex")) + [ROOT / "manuscript/references.bib"]
    sources += [ROOT / "vendor/edbt2027" / name for name in ("acmart.cls", "edbt-macros.tex", "ACM-Reference-Format.bst")]
    sources += list((ROOT / "vendor/fonts").glob("*.otf"))
    for source in sources:
        shutil.copy2(source, stage / source.name)
    shutil.copytree(ROOT / "manuscript/generated", stage / "generated", dirs_exist_ok=True)
    result = subprocess.run([executable, "--keep-logs", "--keep-intermediates", "main.tex"], cwd=stage, capture_output=True, text=True)
    (stage / "build-output.txt").write_text(result.stdout + result.stderr)
    print(result.stdout + result.stderr)
    result.check_returncode()
    output = ROOT / "manuscript/edbt2027-collision-audit-draft.pdf"
    shutil.copy2(stage / "main.pdf", output)
    version = subprocess.run([executable, "--version"], capture_output=True, text=True, check=True)
    write_json(ROOT / "manuscript/build_manifest.json", {"status": "working draft, not submission-ready", "engine": version.stdout.strip(), "pdf_sha256": digest(output), "sources": {str(p.relative_to(ROOT)): digest(p) for p in sources}, "generated_manifests": {p.name: digest(p) for p in (ROOT / "manuscript/generated").glob("*manifest.json")}, "generated_assets": {str(p.relative_to(ROOT)): digest(p) for p in (ROOT / "manuscript/generated").iterdir() if p.suffix in (".tex", ".pdf")}})
    print(output)


if __name__ == "__main__":
    main()
