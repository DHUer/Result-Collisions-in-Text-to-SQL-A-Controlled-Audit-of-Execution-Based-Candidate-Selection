"""Run analysis and robustness checks sequentially after primary scoring."""
import datetime
import json
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def main():
    events = ROOT / "reports/postcheck_events.jsonl"
    for script in ("analyze_confirmation.py", "run_sensitivity.py", "diagnose_gold_row_caps.py", "verify_confirmation.py", "render_confirmation.py"):
        with events.open("a") as f:
            f.write(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "script": script, "event": "start"}) + "\n")
        subprocess.run([sys.executable, str(ROOT / "scripts" / script)], cwd=ROOT, check=True)
        with events.open("a") as f:
            f.write(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "script": script, "event": "complete"}) + "\n")


if __name__ == "__main__":
    main()
