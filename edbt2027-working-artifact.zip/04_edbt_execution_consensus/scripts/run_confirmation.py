"""Run the frozen two-model confirmation, stopping on any failed phase."""
import datetime
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, write_json


def main():
    lock = read_json(ROOT / "docs/confirmation_lock.json")
    if any(digest(ROOT / p) != h for p,h in lock["code_sha256"].items()):
        raise ValueError("Frozen core source changed")
    models = [("qwen3b", "qwen2.5-3b-instruct-q8_0.gguf"), ("llama3b", "Llama-3.2-3B-Instruct-Q8_0.gguf")]
    events = ROOT / "runs/confirmation_events.jsonl"
    events.parent.mkdir(exist_ok=True)
    def run(phase, command):
        with events.open("a") as f:
            f.write(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "phase": phase, "event": "start", "command": command}) + "\n")
        subprocess.run(command, cwd=ROOT, check=True)
        with events.open("a") as f:
            f.write(json.dumps({"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "phase": phase, "event": "complete"}) + "\n")
    for index, (name, filename) in enumerate(models):
        completion = ROOT / f"runs/confirmation_{name}/generation_completion.json"
        if completion.exists():
            saved = read_json(completion)
            if saved["complete"] and saved["calls_total"] == 4330 and saved["candidate_sha256"] == digest(completion.parent / "candidates.jsonl"):
                print(f"Preserving completed generation and timing: {name}", flush=True)
                continue
            raise ValueError("Incomplete or changed completion ledger requires inspection")
        run(name + "_generation", [sys.executable, "scripts/run_local.py", "--server", "/opt/homebrew/bin/llama-server", "--model", str(ROOT.parent / "models" / filename), "--model-id", name, "--split", "confirmation", "--run", f"runs/confirmation_{name}", "--port", str(18090 + index), "--protocol-lock", "docs/confirmation_lock.json"])
    for name, _ in models:
        selection = ROOT / f"runs/confirmation_{name}/selection_manifest.json"
        if selection.exists():
            saved = read_json(selection)
            assert saved["selected_sha256"] == digest(selection.parent / "selected.jsonl")
            assert saved["candidate_sha256"] == digest(selection.parent / "candidates.jsonl")
            print(f"Preserving frozen selections: {name}", flush=True)
            continue
        if (selection.parent / "selected.jsonl").exists():
            raise ValueError("Selection ledger exists without its freeze manifest; inspect before continuing")
        run(name + "_selection", [sys.executable, "-m", "collision_audit.cli", "select", "--run", f"runs/confirmation_{name}", "--inputs", "data/processed/confirmation.inputs.jsonl"])
    for name, _ in models:
        run(name + "_evaluation", [sys.executable, "-m", "collision_audit.cli", "evaluate", "--run", f"runs/confirmation_{name}", "--labels", "data/processed/confirmation.labels.jsonl", "--workers", "4"])
        run(name + "_report", [sys.executable, "-m", "collision_audit.cli", "report", "--run", f"runs/confirmation_{name}", "--output", f"reports/confirmation_{name}", "--label", f"Frozen confirmation: {name}"])
    write_json(ROOT / "runs/confirmation_complete.json", {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "models": [x[0] for x in models], "complete": True})


if __name__ == "__main__":
    main()
