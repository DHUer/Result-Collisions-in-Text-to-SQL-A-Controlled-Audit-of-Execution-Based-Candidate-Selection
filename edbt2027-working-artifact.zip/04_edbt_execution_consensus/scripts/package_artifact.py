"""Package code and compact research materials, never datasets or model weights."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, write_json


def main():
    files = [ROOT / name for name in ("README.md", "RUNNING.md", "pyproject.toml", ".gitignore", "LICENSE", ".zenodo.json")]
    files.append(ROOT / "docs/confirmation_lock.zip")
    allowed = {".py", ".md", ".json", ".jsonl", ".html", ".tex", ".bib", ".bst", ".cls", ".pdf", ".svg", ".otf", ".txt"}
    excluded = {"sample-base.bib", "package_manifest.json", "artifact_reproduction.json"}
    for folder in ("src", "scripts", "tests", "configs", "docs", "reports", "manuscript", "vendor"):
        for path in (ROOT / folder).rglob("*"):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts and path.name not in excluded:
                if path.suffix in allowed or path.name == "LICENSE":
                    files.append(path)
    files = sorted(set(files))
    archive = ROOT / "artifacts/edbt2027-working-artifact.zip"
    archive.parent.mkdir(parents=True, exist_ok=True)
    manifest = {str(p.relative_to(ROOT)): digest(p) for p in files}
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in files:
            relative = str(path.relative_to(ROOT))
            info = zipfile.ZipInfo("04_edbt_execution_consensus/" + relative, date_time=(2026, 9, 30, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
        z.writestr("04_edbt_execution_consensus/FILE_MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for relative, expected in manifest.items():
            assert hashlib.sha256(z.read("04_edbt_execution_consensus/" + relative)).hexdigest() == expected
    result = {"archive": str(archive.relative_to(ROOT)), "sha256": digest(archive), "bytes": archive.stat().st_size, "files": len(files) + 1, "excluded": ["raw/processed datasets", "model weights", "raw run directories", "build caches", "private keys and environment files"], "status": "local working artifact, not a public release or accepted paper"}
    write_json(ROOT / "reports/package_manifest.json", result)
    print(result)


if __name__ == "__main__":
    main()
