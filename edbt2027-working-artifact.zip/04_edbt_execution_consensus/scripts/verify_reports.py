"""Recompute summaries and validate every saved witness without model generation."""
import argparse
import itertools
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, read_jsonl, write_json
from collision_audit.comparator import equivalent
from collision_audit.data import original_database, suite_databases
from collision_audit.execution import execute_batch
from collision_audit.reporting import summarize
from collision_audit.selection import choose, groups


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute-witnesses", action="store_true", help="Requires the public databases, but no LLM")
    args = parser.parse_args()
    output = {"reports": {}, "witnesses_reexecuted": args.execute_witnesses}
    labels_path = ROOT / "data/processed/pilot.labels.jsonl"
    labels = {r["id"]: r for r in read_jsonl(labels_path)} if args.execute_witnesses else {}
    for model in ("qwen", "llama"):
        directory = ROOT / f"reports/pilot_{model}3b_v2"
        selected = read_jsonl(directory / "candidate_audit.jsonl")
        evaluated = read_jsonl(directory / "case_audit.jsonl")
        generated = read_jsonl(directory / "generation_audit.jsonl")
        summary = read_json(directory / "summary.json")
        recomputed = summarize(evaluated, selected, generated)
        for key, value in recomputed.items():
            if key != "sqlite_version" and summary[key] != value:
                raise AssertionError(f"Summary differs: {model}:{key}")
        by_id = {r["id"]: r for r in selected}
        checked = 0
        for row in evaluated:
            case = by_id[row["id"]]
            for method, index in case["selected"].items():
                assert choose(case["candidates"], method) == index
            for pair, witness in row["witnesses"].items():
                i, j = map(int, pair.split(","))
                assert case["candidates"][i]["sql"].strip() != case["candidates"][j]["sql"].strip()
                assert witness["left"]["status"] == witness["right"]["status"] == "ok"
                if args.execute_witnesses:
                    gold = labels[row["id"]]["gold_sql"]
                    ordered = "order by" in gold.lower()
                    assert equivalent(case["candidates"][i]["execution"], case["candidates"][j]["execution"], ordered)
                    database = next(p for p in suite_databases(row["db_id"]) if p.name == witness["database"])
                    # A witness must not merely replay byte-identical original data.
                    assert digest(database) != digest(original_database(row["db_id"]))
                    left, right = execute_batch(database, [case["candidates"][i]["sql"], case["candidates"][j]["sql"]])
                    assert left["status"] == right["status"] == "ok"
                    assert not equivalent(left, right, ordered)
                    assert equivalent(left, witness["left"], ordered) and equivalent(right, witness["right"], ordered)
                checked += 1
        output["reports"][model] = {"questions": len(evaluated), "samples": len(generated), "verified_selector_decisions": len(selected) * len(selected[0]["selected"]), "witness_pairs": checked, "summary_sha256": digest(directory / "summary.json")}
    write_json(ROOT / "reports/reproduction_check.json", output)
    print(output)


if __name__ == "__main__":
    main()

