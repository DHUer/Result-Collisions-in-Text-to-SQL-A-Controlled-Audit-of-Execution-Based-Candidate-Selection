"""Post-hoc diagnosis of ALL gold resource failures, never primary-score repair.

The larger 50,000-row cap was chosen after observing original gold row-limit
failures. Apply it uniformly to all candidates/methods on affected questions;
preserve frozen choices, the 4 MB result cap, and the published primary results.
"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_jsonl, write_json
from collision_audit.comparator import equivalent
from collision_audit.data import original_database, suite_databases
from collision_audit.execution import execute_batch


def main():
    labels = {r["id"]: r for r in read_jsonl(ROOT / "data/processed/confirmation.labels.jsonl")}
    result = {"script_sha256": digest(Path(__file__)), "classification": "post-hoc diagnostic, not replacement primary results", "max_rows": 50000, "max_result_bytes": 4000000, "timeout_seconds": 10., "models": {}}
    for name in ("qwen3b", "llama3b"):
        report = ROOT / f"reports/confirmation_{name}"
        selected = {r["id"]: r for r in read_jsonl(report / "candidate_audit.jsonl")}
        failed = [r for r in read_jsonl(report / "case_audit.jsonl") if r["gold_original"]["status"] == "resource_limit" or any(e["gold_status"] == "resource_limit" for e in r["suite_gold_errors"])]
        checked = []
        for case in failed:
            pool = selected[case["id"]]["candidates"]
            gold = labels[case["id"]]["gold_sql"]
            ordered = "order by" in gold.lower()
            sqls = list(dict.fromkeys([gold] + [c["sql"] for c in pool]))
            correct = [True] * len(pool)
            available = True
            instances = []
            for db in [original_database(case["db_id"])] + suite_databases(case["db_id"]):
                rows = execute_batch(db, sqls, timeout=10., max_rows=50000)
                lookup = dict(zip(sqls, rows))
                g = lookup[gold]
                available &= g["status"] == "ok"
                matches = [equivalent(g, lookup[c["sql"]], ordered) for c in pool]
                correct = [a and b for a,b in zip(correct,matches)]
                instances.append({"database": str(db.relative_to(ROOT)), "sha256": digest(db), "gold_status": g["status"], "gold_rows": len(g.get("rows",[])), "candidate_status": [lookup[c["sql"]]["status"] for c in pool], "candidate_matches": matches})
            checked.append({"id": case["id"], "db_id": case["db_id"], "gold_sql": gold, "available": available, "suite_correct": correct if available else [None]*len(pool), "selected": case["selected"], "instances": instances})
        result["models"][name] = checked
        print(name, [{"id":r["id"],"available":r["available"],"suite_correct":r["suite_correct"],"selected":r["selected"]} for r in checked], flush=True)
    write_json(ROOT / "reports/gold_row_cap_diagnostic.json", result)


if __name__ == "__main__":
    main()
