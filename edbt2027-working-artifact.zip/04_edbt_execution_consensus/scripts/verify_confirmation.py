"""Recompute all choices and independently re-execute every stored witness."""
import collections
import multiprocessing as mp
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.baselines import upstream_choice
from collision_audit.common import digest, read_json, read_jsonl, write_json
from collision_audit.comparator import equivalent
from collision_audit.data import original_database, suite_databases
from collision_audit.execution import execute_batch
from collision_audit.selection import choose, fingerprint
from collision_audit.reporting import summarize


def verify_witnesses(job):
    case, pool, ordered, screened = job
    requests = collections.defaultdict(set)
    for key, witness in case["witnesses"].items():
        requests[witness["database"]].add(tuple(map(int, key.split(","))))
    for witness in screened:
        requests[witness["database"]].add(tuple(witness["pair"]))
    if not requests:
        return {"id": case["id"], "verified_pairs": 0, "instance_pair_checks": 0}
    original = execute_batch(original_database(case["db_id"]), [c["sql"] for c in pool], timeout=10.)
    paths = {p.name: p for p in suite_databases(case["db_id"])}
    checked = 0
    for filename, pairs in requests.items():
        results = execute_batch(paths[filename], [c["sql"] for c in pool], timeout=10.)
        for a, b in pairs:
            assert original[a]["status"] == original[b]["status"] == "ok", (case["id"], "original failure")
            assert fingerprint(original[a]) == fingerprint(original[b]), (case["id"], "original bag drift")
            assert equivalent(original[a], original[b], ordered), (case["id"], "original comparator drift")
            assert results[a]["status"] == results[b]["status"] == "ok", (case["id"], filename, "witness failure")
            assert not equivalent(results[a], results[b], ordered), (case["id"], filename, "not separated")
            key = f"{a},{b}"
            stored = case["witnesses"].get(key)
            if stored and stored["database"] == filename:
                for i, side in ((a, "left"), (b, "right")):
                    assert {k: results[i][k] for k in ("status", "arity", "rows")} == {k: stored[side][k] for k in ("status", "arity", "rows")}, (case["id"], "stored witness output drift")
            checked += 1
    return {"id": case["id"], "verified_pairs": len(case["witnesses"]), "instance_pair_checks": checked}


def main():
    # --extension checks the post-confirmation Gemma run with the same assertions.
    prefix, names = ("extension", ("gemma12b",)) if "--extension" in sys.argv else ("confirmation", ("qwen3b", "llama3b"))
    analysis = read_json(ROOT / f"reports/{prefix}_analysis.json")
    labels = {r["id"]: r for r in read_jsonl(ROOT / "data/processed/confirmation.labels.jsonl")}
    lock = read_json(ROOT / "docs/confirmation_lock.json")
    assert all(digest(ROOT / p) == h for p,h in lock["code_sha256"].items())
    result = {"script_sha256": digest(Path(__file__)), "protocol_source_unchanged": True, "models": {}}
    for name in names:
        report = ROOT / f"reports/{prefix}_{name}"
        selected = read_jsonl(report / "candidate_audit.jsonl")
        cases = read_jsonl(report / "case_audit.jsonl")
        generated = read_jsonl(report / "generation_audit.jsonl")
        summary = read_json(report / "summary.json")
        for key, value in summarize(cases, selected, generated).items():
            if key != "sqlite_version":
                assert summary[key] == value, (name, "numeric report drift", key)
        assert len(cases) == len(selected) == 866 and len(generated) == 4330
        assert {(r["id"],r["sample"]) for r in generated} == {(r["id"],i) for r in selected for i in range(5)}
        pools = {r["id"]: r["candidates"] for r in selected}
        for row in selected:
            for m, expected in row["selected"].items():
                assert choose(row["candidates"], m) == expected, (row["id"], m)
            sqls = [c["sql"] for c in row["candidates"]]
            index = upstream_choice(sqls, [c["dail_execution"] for c in row["candidates"]])
            assert sqls[index] == sqls[row["selected"]["dail_sc"]], (row["id"], "DAIL parity")
        screened = collections.defaultdict(list)
        for w in analysis["models"][name]["constraint_screened_witness_plan"]:
            screened[w["id"]].append(w)
        jobs = [(r, pools[r["id"]], "order by" in labels[r["id"]]["gold_sql"].lower(), screened[r["id"]]) for r in cases]
        with ProcessPoolExecutor(max_workers=4, mp_context=mp.get_context("spawn")) as executor:
            checks = list(executor.map(verify_witnesses, jobs))
        result["models"][name] = {"questions": 866, "samples": 4330, "numeric_summary_reproduced": True, "selection_checks": sum(len(r["selected"]) for r in selected), "published_dail_sql_checks": 866, "witness_pairs_reexecuted": sum(r["verified_pairs"] for r in checks), "instance_pair_checks": sum(r["instance_pair_checks"] for r in checks), "all_passed": True}
        print(name, result["models"][name], flush=True)
    write_json(ROOT / f"reports/{prefix}_verification.json", result)


if __name__ == "__main__":
    main()
