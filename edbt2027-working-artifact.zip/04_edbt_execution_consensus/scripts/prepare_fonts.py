"""Supply the exact math font requested by EDBT's acmart on older TeX bundles."""
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, write_json
from prepare_assets import download


def main():
    url = "https://github.com/alerque/libertinus/releases/download/v7.051/Libertinus-7.051.zip"
    archive = ROOT / ".cache/Libertinus-7.051.zip"
    download(url, archive, cap=20_000_000)
    checksum = digest(archive)
    target = ROOT / "vendor/fonts"
    target.mkdir(parents=True, exist_ok=True)
    manifest = target / "manifest.json"
    if manifest.exists() and read_json(manifest)["archive_sha256"] != checksum:
        raise ValueError("Font archive changed")
    mapping = {"Libertinus-7.051/static/OTF/LibertinusMath-Regular.otf": "libertinusmath-regular.otf", "Libertinus-7.051/OFL.txt": "Libertinus-OFL.txt"}
    with zipfile.ZipFile(archive) as z:
        for member, filename in mapping.items():
            data = z.read(member)
            dest = target / filename
            if dest.exists() and dest.read_bytes() != data:
                raise ValueError("Font asset differs")
            dest.write_bytes(data)
    write_json(manifest, {"url": url, "archive_sha256": checksum, "files": {name: digest(target / name) for name in mapping.values()}, "note": "Unmodified Libertinus Math 7.051 requested by official acmart; only filename case normalized. SIL OFL retained."})


if __name__ == "__main__":
    main()

