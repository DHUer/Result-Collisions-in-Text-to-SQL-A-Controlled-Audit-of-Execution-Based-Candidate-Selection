"""PDF format checks; run with PyMuPDF installed. Does not certify acceptance."""
import hashlib
import json
import re
from pathlib import Path
import fitz

ROOT = Path(__file__).resolve().parents[1]


def main():
    path = ROOT / "manuscript/edbt2027-collision-audit-draft.pdf"
    doc = fitz.open(path)
    texts = [page.get_text() for page in doc]
    text = "\n".join(texts)
    page_sizes = [[round(page.rect.width, 2), round(page.rect.height, 2)] for page in doc]
    assert all(abs(w - 595.28) < .1 and abs(h - 841.89) < .1 for w, h in page_sizes)
    assert len(doc) <= 12  # conservative: includes references/artifacts too
    assert "??" not in text and "Pending" not in text.split("Abstract")[0]
    assert "Artifacts" in text and text.rfind("Artifacts") < text.rfind("References")
    reference_count = 8
    figure_count = len(re.findall(r"Figure \d+:", text))
    assert all(f"[{i}]" in text for i in range(1, reference_count + 1))
    assert figure_count >= 4
    assert all(f"Figure {i}:" in text for i in range(1, figure_count + 1))
    assert "Table 1:" in text
    fonts = {}
    for page in doc:
        for item in page.get_fonts(full=True):
            xref, ext, kind, name = item[:4]
            if xref:
                extracted = doc.extract_font(xref)
                fonts[name] = {"extension": ext, "embedded_bytes": len(extracted[3])}
    assert all(f["embedded_bytes"] > 0 for f in fonts.values())
    log = (ROOT / "build/paper/main.log").read_text()
    biblog = (ROOT / "build/paper/main.blg").read_text()
    assert "Overfull" not in log
    assert "Warning--" not in biblog
    assert not re.search(r"(?:Citation|Reference) .* undefined", log)
    result = {
        "pdf_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "pages": len(doc),
        "page_sizes_pt": page_sizes, "numbered_references": reference_count, "figures": figure_count,
        "raster_image_count": sum(len(p.get_images()) for p in doc), "fonts": fonts,
        "overfull_boxes": 0, "bibtex_warnings": 0, "unresolved_references": 0,
        "author_details_pending": False, "release_pending": "Release pending" in text,
        # Format-level only; human scientific review is tracked in docs/READINESS.md.
        "submission_ready": "Release pending" not in text and "pending" not in text.lower(),
        "note": "Official template retained. Underfull-box and font-request diagnostics can remain; all PDF fonts are embedded. Scientific readiness is separate.",
    }
    (ROOT / "manuscript/format_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ("pages", "figures", "numbered_references", "overfull_boxes", "submission_ready")}, indent=2))


if __name__ == "__main__":
    main()
