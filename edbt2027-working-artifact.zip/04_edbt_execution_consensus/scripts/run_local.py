"""Launch only our own localhost server, generate a pool, and always stop it."""
import argparse
import datetime
import os
import platform
import socket
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from collision_audit.common import digest, read_json, write_json
from collision_audit.generation import generate, request


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--server", default="llama-server")
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--model-id", required=True)
    p.add_argument("--split", choices=("pilot", "confirmation"), default="pilot")
    p.add_argument("--run", type=Path, required=True)
    p.add_argument("--port", type=int, default=18089)
    p.add_argument("--protocol-lock", type=Path)
    # Server-side switches only (e.g. --reasoning-budget 0); request payloads stay frozen.
    p.add_argument("--server-arg", action="append", default=[])
    args = p.parse_args()
    # Require an explicit local protocol freeze before spending confirmation runs.
    # This is a workflow guard, not a security boundary or a venue preregistration.
    if args.split == "confirmation":
        if not args.protocol_lock or not args.protocol_lock.is_file():
            p.error("Confirmation requires --protocol-lock with a frozen, reviewed protocol manifest")
        lock = read_json(args.protocol_lock)
        if lock.get("protocol_sha256") != digest(ROOT / "docs/PROTOCOL.md") or lock.get("split_sha256") != digest(ROOT / "docs/split_manifest.json"):
            p.error("Protocol lock does not match current protocol and split")
        if lock.get("config_sha256") != digest(ROOT / "configs/study.json"):
            p.error("Frozen configuration changed")
        current_code = {str(path.relative_to(ROOT)): digest(path) for path in sorted((ROOT / "src").rglob("*.py"))}
        if current_code != lock.get("code_sha256"):
            p.error("Frozen source code changed")
    config = read_json(ROOT / "configs/study.json")
    if (config["k"], config["temperature"], config["top_p"], config["seed"], config["max_tokens"]) != (5, 0.7, 0.95, 2701, 384):
        p.error("Settings changed: version the runner and protocol rather than silently drift")
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", args.port))
        except OSError:
            p.error("Port already in use; choose another. Existing services will not be stopped.")
    endpoint = f"http://127.0.0.1:{args.port}"
    args.run.mkdir(parents=True, exist_ok=True)
    command = [args.server, "--model", str(args.model.resolve()), "--alias", args.model_id,
               "--host", "127.0.0.1", "--port", str(args.port), "--ctx-size", str(config["context_size"] * config["server_parallel_slots"]),
               "--parallel", str(config["server_parallel_slots"]), "--n-gpu-layers", "99", "--no-ui", "--cors-origins", endpoint] + args.server_arg
    version = subprocess.run([args.server, "--version"], capture_output=True, text=True, check=True)
    hardware = {"platform": platform.platform(), "cpu_count": os.cpu_count()}
    for tool_command in (["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv"], ["sysctl", "-n", "machdep.cpu.brand_string", "hw.memsize"]):
        try:
            r = subprocess.run(tool_command, capture_output=True, text=True, timeout=10)
            if r.returncode == 0:
                hardware[tool_command[0]] = r.stdout.strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
    launch = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "command": command, "version": version.stdout + version.stderr, "hardware": hardware, "protocol_lock": str(args.protocol_lock) if args.protocol_lock else None}
    # Append launch history on resume instead of replacing original launch provenance.
    with (args.run / "launch_history.jsonl").open("a") as f:
        import json
        f.write(json.dumps(launch) + "\n")
    with (args.run / "server.log").open("a") as log:
        server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        try:
            deadline = time.monotonic() + 120
            while time.monotonic() < deadline:
                if server.poll() is not None:
                    raise RuntimeError("Server exited; inspect server.log")
                try:
                    if request(endpoint + "/health", timeout=2).get("status") == "ok":
                        break
                except Exception:
                    pass
                time.sleep(0.5)
            else:
                raise TimeoutError("Server did not become healthy")
            print(generate(ROOT / f"data/processed/{args.split}.inputs.jsonl", args.run, endpoint, args.model, args.model_id, k=config["k"], max_tokens=config["max_tokens"], temperature=config["temperature"], seed=config["seed"], max_workers=config["server_parallel_slots"]))
        finally:
            if server.poll() is None:
                server.terminate()
                try:
                    server.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()


if __name__ == "__main__":
    main()
