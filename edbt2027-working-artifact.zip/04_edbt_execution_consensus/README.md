# EDBT 2027: Execution-Consensus Audit for Text-to-SQL

**Status: working paper and runnable research artifact, not submission-ready.**
This is a new database-focused study, separate from the GGUF-throughput and BFCL
argument-grounding papers. All project-specific code, protocol, manuscript,
figures, reports, and downloaded assets live in this folder. Model weights may be
supplied from any local path; the first pilot reuses existing weights, not results.

**Working title:** *[EA&B] Result Collisions in Text-to-SQL: A Controlled Audit of
Execution-Based Candidate Selection*.

**Topical area:** Natural language processing for databases, under Data management
and AI. **Submission category:** Experiments, Analysis & Benchmarks (EA&B).
These are different choices on the submission form.

## Research question

When several LLM-generated SQL queries return the same result on one database,
how often do the official evaluation database instances distinguish them? Does
that hidden disagreement actually change which SQL query a voting rule selects?

The proposed contribution is an audit linking **observable result representation,
distinct-query collisions, and downstream selection errors**, with a fixed shared
candidate pool. It is not the invention of execution voting or counterexample
databases. Closely related 2025–2026 work makes novelty a real risk; see
[RELATED_WORK.md](docs/RELATED_WORK.md).

## Start here

- [Paper PDF](manuscript/edbt2027-collision-audit-draft.pdf) and [LaTeX source](manuscript/main.tex).
- [Verified venue requirements](docs/VENUE.md).
- [Experimental protocol and confirmation gates](docs/PROTOCOL.md).
- [Local/RTX 5080 run instructions](RUNNING.md).
- [Measured Qwen pilot](reports/pilot_qwen3b_v2/RESULTS.md) and [Llama pilot](reports/pilot_llama3b_v2/RESULTS.md).
- [Full confirmation evidence](reports/CONFIRMATION_EVIDENCE.md),
  [paired analysis](reports/confirmation_analysis.json), and
  [documented sensitivity correction](docs/SENSITIVITY_AMENDMENT.md).
- [Gemma-4-12B post-confirmation extension](reports/extension_gemma12b/RESULTS.md)
  and [its paired analysis](reports/extension_analysis.json).
- [Current readiness and remaining work](docs/READINESS.md).

## Layout

```text
configs/             fixed settings for pilot and confirmation
src/collision_audit/  input isolation, local inference, selection, scoring, reports
scripts/             public-asset preparation, local launch, figures, PDF build
tests/               safety, scoring, selection, leakage, statistics tests
data/raw/            downloaded datasets and evaluation instances (gitignored)
data/processed/      separate inference inputs and gold labels (gitignored)
runs/                resumable raw runs, model/server provenance (gitignored)
reports/             compact measured results and candidate-level audit artifacts
manuscript/          EDBT-formatted paper, numbered references, generated figures
vendor/              unchanged EDBT template and pinned upstream comparator source
docs/                protocol, literature, deadline snapshot, hashes, readiness
```

No paid API, model training, or communication among the three machines is required.
Use the RTX 5080 for generation, the Mac Studio for the other model family or CPU
evaluation, and the MacBook for development/analysis. Keep each model/backend run
separate; hardware speed is not this paper's research claim.

Completed locally: the original 240-call pilot plus **8,660 confirmation calls**
on all 866 reserved questions, ten shared-pool selectors including DAIL-SQL's
released aggregation, and 66,314 question–suite-instance evaluations. Two reference
queries exceed the row cap, so primary paired scores use 864 questions per model.
Both models show that executable filtering accounts for most of the net gain
over the first candidate. See the evidence report for intervals, null findings,
failure decomposition, constraint checks and resource sensitivity. Initial pilot
reports and the pre-confirmation manuscript snapshot are retained.

Do not upload the present PDF unchanged: author details, independent human
scientific review, licensing and an accessible artifact release are still required.
Nothing in this folder has been submitted to EDBT or pushed to GitHub by this task.
