import collections
import random
import sqlite3
from pathlib import Path
from .common import ROOT, digest, read_json, read_jsonl, write_json, write_jsonl
from .selection import METHODS, groups, result_kind


def paired_cluster_interval(cases, method, baseline="first", repeats=4000, seed=2701):
    valid = [r for r in cases if r["evaluation_valid"]]
    by_db = collections.defaultdict(list)
    for case in valid:
        score = case["suite_correct"]
        by_db[case["db_id"]].append(int(score[case["selected"][method]]) - int(score[case["selected"][baseline]]))
    ids = sorted(by_db)
    if len(ids) < 2:
        return None
    rng = random.Random(seed)
    values = []
    for _ in range(repeats):
        sampled = [by_db[rng.choice(ids)] for _ in ids]
        values.append(sum(sum(v) for v in sampled) / sum(len(v) for v in sampled))
    values.sort()
    return [values[int(repeats * 0.025)], values[min(repeats - 1, int(repeats * 0.975))]]


def summarize(evaluated, selected, generated):
    valid = [r for r in evaluated if r["evaluation_valid"]]
    kinds = collections.Counter(k for r in evaluated for k in r["candidate_kinds"])
    metrics = {}
    for method in evaluated[0]["selected"]:
        orig_cases = [r for r in evaluated if r["original_correct"][r["selected"][method]] is not None]
        original = sum(bool(r["original_correct"][r["selected"][method]]) for r in orig_cases)
        suite = sum(bool(r["suite_correct"][r["selected"][method]]) for r in valid)
        reassurance = [r for r in valid if r["original_correct"][r["selected"][method]]]
        metrics[method] = {
            "original_correct": original, "original_denominator": len(orig_cases),
            "suite_correct": suite, "suite_denominator": len(valid),
            "false_reassurance": sum(not r["suite_correct"][r["selected"][method]] for r in reassurance),
            "false_reassurance_denominator": len(reassurance),
            "paired_suite_delta_ci95_vs_first": paired_cluster_interval(evaluated, method),
        }
    strata = {}
    for kind in ("empty", "scalar_zero", "scalar_null", "other", "invalid"):
        rows = [r for r in valid if r["candidate_kinds"][r["selected"]["execution_bag"]] == kind]
        observed_pass = [r for r in rows if r["original_correct"][r["selected"]["execution_bag"]]]
        strata[kind] = {"cases": len(rows), "original_pass": len(observed_pass), "suite_pass": sum(r["suite_correct"][r["selected"]["execution_bag"]] for r in rows), "false_reassurance": sum(not r["suite_correct"][r["selected"]["execution_bag"]] for r in observed_pass)}
    return {
        "questions": len(evaluated), "databases": len({r["db_id"] for r in evaluated}), "valid_suite_questions": len(valid),
        "invalid_gold_questions": len(evaluated) - len(valid), "candidate_calls": len(generated),
        "request_failures": sum(r["status"] != "ok" for r in generated),
        "truncated_responses": sum(r.get("finish_reason") == "length" for r in generated),
        "candidate_result_kinds": dict(kinds), "metrics": metrics, "execution_vote_strata": strata,
        "questions_with_distinct_sql_agreement": sum(r["collision_pairs_observed"] > 0 for r in evaluated),
        "questions_with_witnessed_collision": sum(r["collision_pairs_separated"] > 0 for r in evaluated),
        "distinct_sql_pairs_agreeing": sum(r["collision_pairs_observed"] for r in evaluated),
        "distinct_sql_pairs_separated": sum(r["collision_pairs_separated"] for r in evaluated),
        "arity_blind_selection_changes": sum(r["selection_changed"] for r in evaluated),
        "unique_sql_total": sum(len({c["sql"].strip() for c in r["candidates"]}) for r in selected),
        "oracle_suite_pass_at_k_count": sum(any(r["suite_correct"]) for r in valid),
        "prompt_tokens": sum(r.get("usage", {}).get("prompt_tokens", 0) for r in generated),
        "completion_tokens": sum(r.get("usage", {}).get("completion_tokens", 0) for r in generated),
        "generation_elapsed_seconds": sum(r["elapsed_seconds"] for r in generated),
        "suite_instance_executions": sum(len(r["instances"]) for r in evaluated),
        "sqlite_version": sqlite3.sqlite_version,
        "uncertainty_note": "Paired percentile bootstrap resamples whole database clusters (4000, seed 2701). Very few pilot databases make these intervals exploratory, not confirmatory.",
    }


def report(run, output, label, evaluation_output=None):
    run, output = Path(run), Path(output)
    evaluation_output = Path(evaluation_output) if evaluation_output else run
    evaluated = read_jsonl(evaluation_output / "evaluated.jsonl")
    selected = read_jsonl(run / "selected.jsonl")
    generated = read_jsonl(run / "candidates.jsonl")
    summary = summarize(evaluated, selected, generated)
    summary["study_label"] = label
    summary["provenance"] = {name: digest((evaluation_output if name in ("evaluated.jsonl", "evaluation_manifest.json") else run) / name) for name in ("evaluated.jsonl", "selected.jsonl", "candidates.jsonl", "generation_manifest.json", "selection_manifest.json", "evaluation_manifest.json")}
    summary["reporting_code_sha256"] = digest(Path(__file__))
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "summary.json", summary)
    # Compact, independently inspectable artifact without redistributing database ZIPs.
    write_jsonl(output / "case_audit.jsonl", evaluated)
    write_jsonl(output / "candidate_audit.jsonl", selected)
    write_jsonl(output / "generation_audit.jsonl", [{k: v for k, v in r.items() if k != "response"} for r in generated])
    for name in ("generation_manifest.json", "selection_manifest.json", "evaluation_manifest.json", "server_snapshot.json"):
        write_json(output / name, read_json((evaluation_output if name == "evaluation_manifest.json" else run) / name))
    lines = [f"# {label.title()}", "", "Measured results only. This custom Spider-dev partition is not a full benchmark score.", "", f"{summary['questions']} questions, {summary['databases']} databases, {summary['candidate_calls']} generated samples.", "", "| Selector | Original pass | Suite pass | False reassurance |", "|---|---:|---:|---:|"]
    for name, m in summary["metrics"].items():
        lines.append(f"| {name} | {m['original_correct']}/{m['original_denominator']} | {m['suite_correct']}/{m['suite_denominator']} | {m['false_reassurance']}/{m['false_reassurance_denominator']} |")
    lines += ["", f"Witnessed collisions: {summary['questions_with_witnessed_collision']} questions; {summary['distinct_sql_pairs_separated']}/{summary['distinct_sql_pairs_agreeing']} distinct-SQL pairs with identical typed-bag observations separated on at least one official suite instance.", "", "Pair counts are diagnostic, not independent statistical samples. Failure to find a witness does not establish semantic equivalence.", "", f"Candidate result categories: {summary['candidate_result_kinds']}", "", f"Invalid-gold questions: {summary['invalid_gold_questions']}; truncated responses: {summary['truncated_responses']}; request failures: {summary['request_failures']}.", "", "No claim of improved selection, generality, novelty, or publication readiness follows from this pilot."]
    (output / "RESULTS.md").write_text("\n".join(lines) + "\n")
    return summary
