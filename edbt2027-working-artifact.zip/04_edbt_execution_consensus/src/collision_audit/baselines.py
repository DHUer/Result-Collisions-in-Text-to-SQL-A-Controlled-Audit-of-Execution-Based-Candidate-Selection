"""DAIL-SQL aggregation baseline, isolated from its unrestricted SQL executor.

This reproduces the released SC aggregation/preprocessing stage, not its GPT-4
generator, few-shot retrieval, or original benchmark results.
"""
import ast
import re
import sqlparse
from .common import ROOT, digest, read_json
from .comparator import equivalent


def dail_preprocess(sql):
    # Same order as get_exec_output -> exec_on_db_ at the pinned upstream commit.
    sql = sql.replace("> =", ">=").replace("< =", "<=").replace("! =", "!=")
    try:
        toks = [t.value for t in list(sqlparse.parse(sql)[0].flatten())]
        sql = "".join(t for t in toks if t.lower() != "distinct")
    except Exception:
        return ""  # upstream returns an exception; empty SQL is a failed sample
    return re.sub(r"YEAR\s*\(\s*CURDATE\s*\(\s*\)\s*\)\s*", "2020", sql, flags=re.I)


def execution_groups(candidates, field="execution"):
    clusters = []
    for i, candidate in enumerate(candidates):
        result = candidate[field]
        if result["status"] != "ok":
            continue
        for cluster in clusters:
            if equivalent(candidates[cluster[0]][field], result, ordered=False):
                cluster.append(i)
                break
        else:
            clusters.append([i])
    return clusters


def execution_choice(candidates, field="execution"):
    clusters = execution_groups(candidates, field)
    return min(clusters, key=lambda c: (-len(c), c[0]))[0] if clusters else 0


def upstream_choice(sqls, executions):
    """Test oracle: unchanged upstream get_sqls, with only execution stubbed.

    Vendor source is pinned and preserved; neither its imports nor executor run.
    """
    path = ROOT / "vendor/dail_sql/post_process.py"
    expected = read_json(ROOT / "vendor/dail_sql/manifest.json")["post_process.py"]["sha256"]
    if digest(path) != expected:
        raise ValueError("DAIL-SQL source drift")
    node = next(n for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name == "get_sqls")
    by_sql = dict(zip(sqls, executions))
    def execute(db, sql):
        result = by_sql[sql]
        return ("result", [tuple(row) for row in result["rows"]]) if result["status"] == "ok" else ("exception", [])
    from .comparator import comparator
    class Progress:
        tqdm = staticmethod(lambda x: x)
    env = {"get_exec_output": execute, "result_eq": comparator(), "tqdm": Progress, "print": lambda *args, **kwargs: None}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), env)
    chosen = env["get_sqls"]([{"db_id": "fixture", "p_sqls": sqls}], len(sqls), "unused")[0]
    return sqls.index(chosen)

