"""Export a gold-free inference view and a separate evaluation-only label file."""
import sqlite3
from pathlib import Path
from .common import ROOT, digest, read_json, stable_hash, write_json, write_jsonl

SALT = "edbt-2027-collision-audit-v1"


def schema_for(path):
    with sqlite3.connect(path.resolve().as_uri() + "?mode=ro&immutable=1", uri=True) as conn:
        rows = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
    return "\n\n".join(row[0] + ";" for row in rows if row[0])


def prepare(pilot_databases=4, pilot_per_database=6):
    spider = ROOT / "data/raw/spider/spider_data"
    raw = read_json(spider / "dev.json")
    database_ids = sorted({r["db_id"] for r in raw}, key=lambda db: stable_hash([SALT, db]))
    if not 0 < pilot_databases < len(database_ids):
        raise ValueError("Need disjoint pilot and confirmation database sets")
    pilot_ids = database_ids[:pilot_databases]
    schema = {}
    db_hashes = {}
    for db_id in database_ids:
        path = spider / "database" / db_id / (db_id + ".sqlite")
        schema[db_id] = schema_for(path)
        db_hashes[db_id] = digest(path)
    cases = []
    for index, row in enumerate(raw):
        cases.append({"id": f"spider-dev-{index:04d}", "db_id": row["db_id"], "question": row["question"], "schema": schema[row["db_id"]]})
    pilot_case_ids = set()
    for db_id in pilot_ids:
        available = sorted((r for r in cases if r["db_id"] == db_id), key=lambda r: stable_hash([SALT, r["id"]]))
        pilot_case_ids.update(r["id"] for r in available[:pilot_per_database])
    split_ids = {
        "pilot": [r["id"] for r in cases if r["id"] in pilot_case_ids],
        "confirmation": [r["id"] for r in cases if r["db_id"] not in pilot_ids],
        "quarantined": [r["id"] for r in cases if r["db_id"] in pilot_ids and r["id"] not in pilot_case_ids],
    }
    manifest = {
        "salt": SALT, "pilot_databases": pilot_ids, "confirmation_databases": database_ids[pilot_databases:],
        "pilot_per_database": pilot_per_database, "case_ids": split_ids,
        "dev_sha256": digest(spider / "dev.json"), "tables_sha256": digest(spider / "tables.json"),
        "database_sha256": db_hashes,
        "note": "Custom database-disjoint partition of public Spider dev; not the standard full-dev leaderboard score. No test.json used.",
    }
    manifest_path = ROOT / "docs/split_manifest.json"
    if manifest_path.exists() and read_json(manifest_path) != manifest:
        raise ValueError("Existing split differs: create a new explicitly versioned protocol")
    write_json(manifest_path, manifest)
    for split, ids in split_ids.items():
        selected = set(ids)
        inputs = [r for r in cases if r["id"] in selected]
        labels = [{"id": f"spider-dev-{i:04d}", "db_id": r["db_id"], "gold_sql": r["query"]} for i, r in enumerate(raw) if f"spider-dev-{i:04d}" in selected]
        write_jsonl(ROOT / f"data/processed/{split}.inputs.jsonl", inputs)
        write_jsonl(ROOT / f"data/processed/{split}.labels.jsonl", labels)
    return {"counts": {s: len(ids) for s, ids in split_ids.items()}, "pilot_databases": pilot_ids}


def original_database(db_id):
    # IDs come from our prepared manifest, never from generated SQL.
    manifest = read_json(ROOT / "docs/split_manifest.json")
    if db_id not in manifest["database_sha256"]:
        raise ValueError("Unrecognized database ID")
    path = ROOT / "data/raw/spider/spider_data/database" / db_id / (db_id + ".sqlite")
    if digest(path) != manifest["database_sha256"][db_id]:
        raise ValueError("Original database changed")
    return path


def suite_databases(db_id):
    original_database(db_id)  # validates ID and pinned original
    root = ROOT / "data/raw/testsuite"
    # The official archive uses database/<db_id>/*.sqlite.
    directory = root / "database" / db_id
    if not directory.is_dir():
        raise FileNotFoundError(f"Expected official suite directory: {directory}")
    paths = sorted(directory.glob("*.sqlite"))
    if not paths:
        raise ValueError("Empty evaluation suite")
    return paths

