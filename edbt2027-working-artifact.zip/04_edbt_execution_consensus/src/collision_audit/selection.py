"""Selectors see generated SQL and original-database results only; never gold."""
import json
import re
from collections import defaultdict


def extract_sql(text):
    text = text.strip()
    match = re.fullmatch(r"```(?:sql|sqlite)?\s*\n?(.*?)\n?```", text, flags=re.I | re.S)
    return match.group(1).strip() if match else text


def result_kind(result):
    if result["status"] != "ok":
        return "invalid"
    rows = result["rows"]
    if not rows:
        return "empty"
    if len(rows) == 1 and result["arity"] == 1:
        if rows[0][0] is None:
            return "scalar_null"
        if type(rows[0][0]) in (int, float) and rows[0][0] == 0:
            return "scalar_zero"
    return "other"


def fingerprint(result, ordered=False, arity=True):
    if result["status"] != "ok":
        raise ValueError("Failures are not voting answers")
    rows = [json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) for row in result["rows"]]
    if not ordered:
        rows.sort()  # bags, not sets: duplicates are retained
    # Column order and numeric JSON type are deliberately preserved in this selector.
    # The scorer uses the separate official result comparator.
    return (result["arity"] if arity else None, tuple(rows))


def groups(candidates, mode):
    grouped = defaultdict(list)
    for i, candidate in enumerate(candidates):
        result = candidate["execution"]
        if mode == "exact_sql":
            key = candidate["sql"].strip()
        elif mode == "exact_sql_executable":
            if result["status"] != "ok":
                continue
            key = candidate["sql"].strip()
        else:
            if result["status"] != "ok":
                continue
            key = fingerprint(result, ordered=mode == "execution_ordered", arity=mode != "execution_arity_blind")
        grouped[key].append(i)
    return list(grouped.values())


METHODS = ("first", "first_executable", "exact_sql", "exact_sql_executable", "execution_bag", "execution_ordered", "execution_arity_blind", "execution_unique_sql", "execution_official", "dail_sc")


def choose(candidates, method):
    if not candidates:
        raise ValueError("Candidate pool is empty")
    if method == "first":
        return 0
    if method == "first_executable":
        return next((i for i, c in enumerate(candidates) if c["execution"]["status"] == "ok"), 0)
    if method in ("execution_official", "dail_sc"):
        from .baselines import execution_choice
        return execution_choice(candidates, "dail_execution" if method == "dail_sc" else "execution")
    mode = "execution_bag" if method == "execution_unique_sql" else method
    if mode not in METHODS:
        raise ValueError(method)
    clusters = groups(candidates, mode)
    if not clusters:
        return 0  # fixed fallback; invalid candidate remains a scored failure
    def rank(cluster):
        size = len({candidates[i]["sql"].strip() for i in cluster}) if method == "execution_unique_sql" else len(cluster)
        return (-size, min(cluster))
    return min(min(clusters, key=rank))
