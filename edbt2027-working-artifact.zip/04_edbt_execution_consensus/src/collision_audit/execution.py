"""Bounded, read-only SQLite execution. This is not an OS security boundary.

Run public benchmark databases only. For adversarial database files, use an
additional disposable OS/container sandbox. No generated SQL is sent to a shell.
"""
import base64
import json
import math
import multiprocessing as mp
import sqlite3
import time
from pathlib import Path

ALLOWED_ACTIONS = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION, sqlite3.SQLITE_RECURSIVE}
FUNCTIONS = set("abs avg changes char coalesce concat concat_ws count date datetime format glob group_concat hex if iif ifnull instr julianday last_insert_rowid length like likelihood likely load_none lower ltrim max min mod nullif octet_length pow power printf quote random randomblob replace round rtrim sign soundex sqlite_version strftime string_agg substr substring sum time timediff total trim typeof unicode unixepoch unlikely upper zeroblob rank dense_rank row_number percent_rank cume_dist ntile lag lead first_value last_value nth_value".split())
# Non-deterministic results are explicitly excluded from the audit protocol.
FUNCTIONS -= {"random", "randomblob", "changes", "last_insert_rowid"}


def encode_cell(value):
    if isinstance(value, bytes):
        return {"blob_base64": base64.b64encode(value).decode()}
    if isinstance(value, float) and not math.isfinite(value):
        return {"float": repr(value)}
    return value


def decode_cell(value):
    if isinstance(value, dict) and "blob_base64" in value:
        return base64.b64decode(value["blob_base64"])
    if isinstance(value, dict) and "float" in value:
        return float(value["float"])
    return value


def authorize(action, arg1, arg2, db, trigger):
    if action not in ALLOWED_ACTIONS:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_READ and db not in ("main", None):
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_FUNCTION and (arg2 or "").lower() not in FUNCTIONS:
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


def _worker(path, queries, timeout, max_rows, pipe):
    try:
        conn = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
        conn.enable_load_extension(False)
        conn.execute("PRAGMA query_only=ON")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.text_factory = lambda b: b.decode(errors="ignore")
        if hasattr(conn, "setlimit"):
            conn.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, 2_000_000)
            conn.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 100_000)
            conn.setlimit(sqlite3.SQLITE_LIMIT_COLUMN, 256)
        conn.set_authorizer(authorize)
        results = []
        for query in queries:
            start = time.monotonic()
            deadline = start + timeout
            conn.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
            try:
                cursor = conn.execute(query)
                if cursor.description is None:
                    raise ValueError("SQL did not return a relation")
                rows = cursor.fetchmany(max_rows + 1)
                encoded = [[encode_cell(v) for v in row] for row in rows]
                if len(rows) > max_rows or len(json.dumps(encoded)) > 4_000_000:
                    result = {"status": "resource_limit", "error": "result limit exceeded"}
                else:
                    result = {"status": "ok", "arity": len(cursor.description), "rows": encoded}
                cursor.close()
            except (sqlite3.Error, ValueError) as exc:
                status = "timeout" if time.monotonic() >= deadline else "error"
                result = {"status": status, "error": str(exc)}
            result["elapsed_seconds"] = time.monotonic() - start
            results.append(result)
        conn.close()
        pipe.send(results)
    except BaseException as exc:
        pipe.send([{"status": "worker_error", "error": str(exc)} for _ in queries])
    finally:
        pipe.close()


def execute_batch(path, queries, timeout=2.0, max_rows=10000):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if not queries:
        return []
    ctx = mp.get_context("spawn")
    receiving, sending = ctx.Pipe(duplex=False)
    process = ctx.Process(target=_worker, args=(str(path), queries, timeout, max_rows, sending))
    process.start()
    sending.close()
    try:
        if receiving.poll((timeout + 0.5) * len(queries) + 10):
            try:
                return receiving.recv()
            except EOFError:
                return [{"status": "worker_error", "error": "worker exited"} for _ in queries]
        return [{"status": "timeout", "error": "batch wall-clock deadline"} for _ in queries]
    finally:
        receiving.close()
        if process.is_alive():
            process.terminate()
        process.join(5)
        if process.is_alive():
            process.kill()
            process.join()

