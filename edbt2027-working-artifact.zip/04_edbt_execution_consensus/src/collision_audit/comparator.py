"""Load only six unchanged pure functions from pinned upstream evaluator code.

We do NOT import upstream SQL execution, value substitution, pickle, or shell code.
This is comparator-compatible scoring under a bounded, read-only executor, not a
claim of bit-identical official leaderboard evaluation.
"""
import ast
import random
from collections import defaultdict
from itertools import product
from typing import List, Set, Tuple
from .common import ROOT, digest, read_json
from .execution import decode_cell

NAMES = {"permute_tuple", "unorder_row", "quick_rej", "multiset_eq", "get_constraint_permutation", "result_eq"}
_compare = None


def comparator():
    global _compare
    if _compare is None:
        path = ROOT / "vendor/test_suite/exec_eval.py"
        expected = read_json(ROOT / "docs/asset_manifest.json")["test_suite/exec_eval.py"]["sha256"]
        if digest(path) != expected:
            raise ValueError("Upstream comparator source changed")
        tree = ast.parse(path.read_text())
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in NAMES]
        if {n.name for n in nodes} != NAMES:
            raise ValueError("Upstream comparator functions missing")
        env = {"List": List, "Tuple": Tuple, "Set": Set, "product": product, "defaultdict": defaultdict, "random": random.Random(0)}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), env)
        _compare = env["result_eq"]
    return _compare


def equivalent(left, right, ordered=False):
    if left["status"] != "ok" or right["status"] != "ok":
        return False
    lrows = [tuple(decode_cell(v) for v in row) for row in left["rows"]]
    rrows = [tuple(decode_cell(v) for v in row) for row in right["rows"]]
    return comparator()(lrows, rrows, ordered)

