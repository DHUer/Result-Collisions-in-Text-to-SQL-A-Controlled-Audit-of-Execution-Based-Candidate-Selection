import argparse
import json
from .common import ROOT


def main():
    parser = argparse.ArgumentParser(description="EDBT execution-collision study")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    gen = sub.add_parser("generate")
    gen.add_argument("--inputs", type=str, required=True)
    gen.add_argument("--run", required=True)
    gen.add_argument("--endpoint", default="http://127.0.0.1:18081")
    gen.add_argument("--model-path", required=True)
    gen.add_argument("--model-id", required=True)
    gen.add_argument("--k", type=int, default=5)
    gen.add_argument("--max-tokens", type=int, default=384)
    gen.add_argument("--temperature", type=float, default=0.7)
    for name, arg in (("select", "inputs"), ("evaluate", "labels")):
        p = sub.add_parser(name)
        p.add_argument("--run", required=True)
        p.add_argument("--" + arg, required=True)
        p.add_argument("--timeout", type=float, default=2.0)
        if name == "evaluate":
            p.add_argument("--evaluation-output")
            p.add_argument("--workers", type=int, default=1)
    report = sub.add_parser("report")
    report.add_argument("--run", required=True)
    report.add_argument("--output", required=True)
    report.add_argument("--label", default="exploratory pilot")
    report.add_argument("--evaluation-output")
    args = parser.parse_args()
    if args.command == "prepare":
        from .data import prepare
        result = prepare()
    elif args.command == "generate":
        from .generation import generate
        result = generate(args.inputs, args.run, args.endpoint, args.model_path, args.model_id, args.k, args.max_tokens, args.temperature)
    elif args.command == "select":
        from .audit import select_run
        result = select_run(args.run, args.inputs, args.timeout)
    elif args.command == "evaluate":
        from .audit import evaluate_run
        result = evaluate_run(args.run, args.labels, args.timeout, args.evaluation_output, args.workers)
    else:
        from .reporting import report
        result = report(args.run, args.output, args.label, args.evaluation_output)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
