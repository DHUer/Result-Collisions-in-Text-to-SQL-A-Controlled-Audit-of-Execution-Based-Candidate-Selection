"""EDBT execution-consensus audit. No inference happens on import."""

