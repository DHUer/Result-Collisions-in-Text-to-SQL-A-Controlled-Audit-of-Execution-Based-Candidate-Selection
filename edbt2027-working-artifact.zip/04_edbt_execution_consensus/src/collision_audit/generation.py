"""Boundedly concurrent, resumable generation against a local llama.cpp server."""
import datetime
import json
import os
import platform
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from .common import ROOT, digest, read_json, read_jsonl, stable_hash, write_json
from .selection import extract_sql

SYSTEM = "You translate questions into SQLite queries. Return exactly one read-only SELECT query (WITH is allowed). Return SQL only, without markdown or explanation. Use only the supplied schema. Do not assume access to query results."


def messages(case):
    if set(case) != {"id", "db_id", "question", "schema"}:
        raise ValueError("Inference view contains unexpected fields; possible label leakage")
    return [{"role": "system", "content": SYSTEM}, {"role": "user", "content": f"Database schema:\n{case['schema']}\n\nQuestion: {case['question']}\n\nSQLite query:"}]


def local_url(url):
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("This runner permits loopback HTTP endpoints only")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Unexpected endpoint components")
    return url.rstrip("/")


def request(url, payload=None, timeout=240):
    body = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    # Localhost must not be accidentally forwarded through an HTTP proxy.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as response:
        return json.load(response)


def generate(inputs, output, endpoint, model_path, model_id, k=5, max_tokens=384, temperature=0.7, seed=2701, max_workers=1):
    endpoint = local_url(endpoint)
    if k < 1 or k > 32:
        raise ValueError("k must be in [1,32]")
    if not 1 <= max_workers <= 8:
        raise ValueError("max_workers must be in [1,8]")
    inputs, output, model_path = Path(inputs), Path(output), Path(model_path)
    cases = read_jsonl(inputs)
    if len({c["id"] for c in cases}) != len(cases):
        raise ValueError("Duplicate input IDs")
    for case in cases:
        messages(case)
    props = request(endpoint + "/props")
    models = request(endpoint + "/v1/models")
    advertised = {m["id"] for m in models["data"]}
    if model_id not in advertised:
        raise ValueError(f"Requested model ID {model_id!r} not advertised: {advertised}")
    manifest = {
        "inputs_sha256": digest(inputs), "model_sha256": digest(model_path), "model_file": model_path.name,
        "model_id": model_id, "endpoint": endpoint, "k": k, "max_tokens": max_tokens,
        "temperature": temperature, "top_p": 0.95, "seed": seed, "system_prompt": SYSTEM,
        "concurrent_requests": max_workers,
        "generation_code_sha256": digest(Path(__file__)), "selection_code_sha256": digest(ROOT / "src/collision_audit/selection.py"),
        "python": platform.python_version(), "platform": platform.platform(),
    }
    output.mkdir(parents=True, exist_ok=True)
    manifest_path = output / "generation_manifest.json"
    if manifest_path.exists() and read_json(manifest_path) != manifest:
        raise ValueError("Run provenance mismatch; use a new run directory")
    write_json(manifest_path, manifest)
    if not (output / "server_snapshot.json").exists():
        write_json(output / "server_snapshot.json", {"props": props, "models": models, "utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    ledger = output / "candidates.jsonl"
    existing = read_jsonl(ledger) if ledger.exists() else []
    expected = {(c["id"], sample) for c in cases for sample in range(k)}
    seen = {(r["id"], r["sample"]) for r in existing}
    if len(seen) != len(existing) or not seen <= expected:
        raise ValueError("Candidate ledger has duplicate/unexpected IDs")
    lock = output / "generation.lock"
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    def call(case, sample):
        call_seed = int(stable_hash([seed, case["id"], sample])[:8], 16) % (2**31)
        payload = {"model": model_id, "messages": messages(case), "temperature": temperature, "top_p": 0.95, "seed": call_seed, "max_tokens": max_tokens, "stream": False}
        start = time.monotonic()
        row = {"id": case["id"], "db_id": case["db_id"], "sample": sample, "seed": call_seed, "request_sha256": stable_hash(payload)}
        try:
            response = request(endpoint + "/v1/chat/completions", payload)
            choice = response["choices"][0]
            raw = choice["message"]["content"] or ""
            row.update({"status": "ok", "raw": raw, "sql": extract_sql(raw), "finish_reason": choice.get("finish_reason"), "usage": response.get("usage", {}), "response": response})
        except Exception as exc:
            row.update({"status": "request_error", "raw": "", "sql": "", "error": f"{type(exc).__name__}: {exc}"})
        row["elapsed_seconds"] = time.monotonic() - start
        return row
    session_start = time.monotonic()
    initial_count = len(seen)
    try:
        with ledger.open("a", buffering=1) as f, ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(call, case, sample) for case in cases for sample in range(k) if (case["id"], sample) not in seen]
            for future in as_completed(futures):
                row = future.result()
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                f.flush()
                os.fsync(f.fileno())
                seen.add((row["id"], row["sample"]))
                if len(seen) % 25 == 0 or len(seen) == len(expected):
                    print(f"{len(seen)}/{len(expected)} {row['id']} {row['status']} session={time.monotonic()-session_start:.1f}s", flush=True)
        write_json(output / "generation_completion.json", {"complete": len(seen) == len(expected), "calls_this_session": len(seen) - initial_count, "calls_total": len(seen), "session_wall_seconds": time.monotonic() - session_start, "candidate_sha256": digest(ledger), "note": "Summed call latency overlaps with concurrent requests; session wall time is reported separately."})
    finally:
        lock.unlink()
    return {"completed": len(seen), "expected": len(expected), "run": str(output)}
