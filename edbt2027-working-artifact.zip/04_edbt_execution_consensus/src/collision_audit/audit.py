import itertools
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
from importlib.metadata import version
from pathlib import Path
from .common import ROOT, digest, read_json, read_jsonl, stable_hash, write_json, write_jsonl
from .comparator import equivalent
from .data import original_database, suite_databases
from .execution import execute_batch
from .selection import METHODS, choose, groups, result_kind
from .baselines import dail_preprocess


def select_run(run, inputs, timeout=2.0):
    run = Path(run)
    manifest = read_json(run / "generation_manifest.json")
    if digest(inputs) != manifest["inputs_sha256"]:
        raise ValueError("Input hash mismatch")
    cases = read_jsonl(inputs)
    rows = read_jsonl(run / "candidates.jsonl")
    expected = {(c["id"], i) for c in cases for i in range(manifest["k"])}
    actual = [(r["id"], r["sample"]) for r in rows]
    if len(actual) != len(set(actual)) or set(actual) != expected:
        raise ValueError("Candidate pool incomplete, duplicated, or contains unexpected rows")
    by_id = {}
    for row in rows:
        by_id.setdefault(row["id"], []).append(row)
    output = []
    for case in cases:
        candidates = sorted(by_id[case["id"]], key=lambda c: c["sample"])
        results = execute_batch(original_database(case["db_id"]), [c["sql"] for c in candidates], timeout=timeout)
        pool = [{"sample": c["sample"], "sql": c["sql"], "generation_status": c["status"], "execution": r} for c, r in zip(candidates, results)]
        dail_sqls = [dail_preprocess(c["sql"]) for c in pool]
        dail_results = execute_batch(original_database(case["db_id"]), dail_sqls, timeout=timeout)
        for candidate, sql, result in zip(pool, dail_sqls, dail_results):
            candidate.update({"dail_voting_sql": sql, "dail_execution": result})
        selections = {m: choose(pool, m) for m in METHODS}
        output.append({"id": case["id"], "db_id": case["db_id"], "candidates": pool, "selected": selections})
    write_jsonl(run / "selected.jsonl", output)
    write_json(run / "selection_manifest.json", {"candidate_sha256": digest(run / "candidates.jsonl"), "selected_sha256": digest(run / "selected.jsonl"), "timeout_seconds": timeout, "methods": METHODS, "selection_code_sha256": digest(ROOT / "src/collision_audit/selection.py"), "execution_code_sha256": digest(ROOT / "src/collision_audit/execution.py"), "baseline_code_sha256": digest(ROOT / "src/collision_audit/baselines.py"), "dail_manifest_sha256": digest(ROOT / "vendor/dail_sql/manifest.json"), "sqlparse_version": version("sqlparse"), "gold_access": False, "suite_access": False})
    return {"cases": len(output), "methods": len(METHODS)}


def evaluate_run(run, labels, timeout=2.0, evaluation_output=None, workers=1):
    run = Path(run)
    evaluation_output = Path(evaluation_output) if evaluation_output else run
    evaluation_output.mkdir(parents=True, exist_ok=True)
    selected_path = run / "selected.jsonl"
    selection_manifest = read_json(run / "selection_manifest.json")
    if digest(selected_path) != selection_manifest["selected_sha256"] or digest(run / "candidates.jsonl") != selection_manifest["candidate_sha256"]:
        raise ValueError("Selection/candidate ledger changed after freezing")
    cases = read_jsonl(selected_path)
    label_rows = read_jsonl(labels)
    gold = {r["id"]: r for r in label_rows}
    if len(gold) != len(label_rows) or set(gold) != {c["id"] for c in cases}:
        raise ValueError("Evaluation labels must match all selected case IDs exactly")
    all_suites = {db: suite_databases(db) for db in sorted({c["db_id"] for c in cases})}
    suite_hashes = {db: {p.name: digest(p) for p in paths} for db, paths in all_suites.items()}
    provenance = {"selected_sha256": digest(selected_path), "labels_sha256": digest(labels), "suite_sha256": suite_hashes, "timeout_seconds": timeout, "keep_distinct": True, "plug_value": False, "comparator": "six unchanged pure functions from pinned test-suite-sql-eval; safe executor; no SQL rewriting", "audit_code_sha256": digest(Path(__file__)), "execution_code_sha256": digest(ROOT / "src/collision_audit/execution.py"), "comparator_code_sha256": digest(ROOT / "src/collision_audit/comparator.py")}
    provenance_path = evaluation_output / "evaluation_manifest.json"
    if provenance_path.exists() and read_json(provenance_path) != provenance:
        raise ValueError("Evaluation provenance changed; use a new evaluation run")
    write_json(provenance_path, provenance)
    output = []
    cache_dir = evaluation_output / "evaluation_cache"
    cache_dir.mkdir(exist_ok=True)
    jobs = [(case, gold[case["id"]], all_suites[case["db_id"]], timeout, cache_dir / (case["id"] + ".json")) for case in cases]
    if workers == 1:
        results = map(_evaluate_case, jobs)
        executor = None
    else:
        if not 1 <= workers <= 8:
            raise ValueError("workers must be in [1,8]")
        executor = ProcessPoolExecutor(max_workers=workers, mp_context=mp.get_context("spawn"))
        results = executor.map(_evaluate_case, jobs)
    try:
        for number, result in enumerate(results, 1):
            output.append(result)
            if number % 25 == 0 or number == len(cases):
                print(f"Evaluated {number}/{len(cases)}", flush=True)
    finally:
        if executor:
            executor.shutdown(wait=True)
    write_jsonl(evaluation_output / "evaluated.jsonl", output)
    return {"evaluated": len(output), "invalid_gold_cases": sum(not r["evaluation_valid"] for r in output)}


def _evaluate_case(job):
        # Independent worker/comparator state; each cache is written by one job.
        case, label, databases, timeout, cache = job
        if cache.exists():
            return read_json(cache)
        if label["db_id"] != case["db_id"]:
            raise ValueError("Label database ID differs")
        ordered = "order by" in label["gold_sql"].lower()  # matches upstream convention
        pool = case["candidates"]
        original_results = execute_batch(original_database(case["db_id"]), [label["gold_sql"]] + [c["sql"] for c in pool], timeout=timeout)
        original_gold = original_results[0]
        original_valid = original_gold["status"] == "ok"
        original_correct = [equivalent(original_gold, r, ordered) if original_valid else None for r in original_results[1:]]
        correct = [bool(ok) for ok in original_correct]
        # Voting counts samples; collision analysis counts distinct SQL pairs.
        # Otherwise repeated copies of one SQL artificially dilute collision rates.
        representatives = []
        for cluster in groups(pool, "execution_bag"):
            first_by_sql = {}
            for i in cluster:
                first_by_sql.setdefault(pool[i]["sql"].strip(), i)
            representatives.append(list(first_by_sql.values()))
        typed_bag_pairs = sorted({tuple(pair) for cluster in representatives for pair in itertools.combinations(cluster, 2)})
        # A bag can hide row-order disagreement already observable on the original.
        # Such pairs are an observation artifact, not a held-out-instance collision.
        pairs = [pair for pair in typed_bag_pairs if equivalent(pool[pair[0]]["execution"], pool[pair[1]]["execution"], ordered)]
        original_disagreement_pairs = [pair for pair in typed_bag_pairs if pair not in pairs]
        unresolved = set(pairs)
        witnesses = {}
        suite_errors = []
        instances = []
        # No early stopping: audit all prespecified instances and retain gold failures.
        for db in databases:
            unique_sql = list(dict.fromkeys([label["gold_sql"]] + [c["sql"] for c in pool]))
            raw_results = execute_batch(db, unique_sql, timeout=timeout)
            lookup = dict(zip(unique_sql, raw_results))
            g = lookup[label["gold_sql"]]
            results = [lookup[c["sql"]] for c in pool]
            record = {"database": db.name, "gold_status": g["status"], "candidate_status": [r["status"] for r in results]}
            if g["status"] != "ok":
                suite_errors.append({"database": db.name, "gold_status": g["status"], "error": g.get("error")})
            else:
                matches = [equivalent(g, r, ordered) for r in results]
                correct = [old and new for old, new in zip(correct, matches)]
                record["candidate_matches"] = matches
            separated = []
            for left, right in pairs:
                # Errors/timeouts are not semantic counterexamples. Require two successful executions.
                if results[left]["status"] == results[right]["status"] == "ok" and not equivalent(results[left], results[right], ordered):
                    separated.append([left, right])
                    if (left, right) in unresolved:
                        witnesses[f"{left},{right}"] = {"database": db.name, "left": results[left], "right": results[right]}
                        unresolved.remove((left, right))
            record["separated_pairs"] = separated
            instances.append(record)
        evaluation_valid = original_valid and not suite_errors
        result = {"id": case["id"], "db_id": case["db_id"], "evaluation_valid": evaluation_valid,
                  "gold_original_kind": result_kind(original_gold), "gold_original": original_gold,
                  "original_scoring_executions": original_results[1:],
                  "original_correct": original_correct, "suite_correct": correct if evaluation_valid else [None] * len(pool),
                  "suite_gold_errors": suite_errors, "instances": instances,
                  "typed_bag_pairs_observed": len(typed_bag_pairs), "original_comparator_disagreement_pairs": original_disagreement_pairs,
                  "collision_pairs_observed": len(pairs), "collision_pairs_separated": len(witnesses), "witnesses": witnesses,
                  "candidate_kinds": [result_kind(c["execution"]) for c in pool], "selected": case["selected"],
                  "selection_changed": case["selected"]["execution_bag"] != case["selected"]["execution_arity_blind"]}
        write_json(cache, result)
        return result
