# Experimental protocol v0.2

Status: confirmation specification frozen locally before confirmation generation,
**not externally preregistered**. Revised after the 24-question exploratory pilot.
The timestamped lock records exact working-tree source hashes (the repository is
dirty, so a Git revision alone is insufficient). Archive the protocol, config and
source at freezing. Document any subsequent amendment; do not rewrite this file.

## Questions and endpoints

- RQ1: Among distinct SQL pairs with identical typed-bag results on the original
  database, how many are separated by at least one official suite instance?
- RQ2: How often does original-database correctness of the selected query fail to
  persist across the suite? Report numerator/denominator, not just percentages.
- RQ3: Do representation and repetition controls change selection and suite
  correctness? Compare paired outcomes from exactly the same generated pool.
- RQ4: Are these effects concentrated in empty, scalar-zero or scalar-NULL outputs?
  Also report the other-result stratum; a low-information-only claim may fail.

Primary endpoint: paired difference in suite pass rate, execution-bag
voting versus first candidate. The main scientific objective is explanation, not
necessarily a positive gain. Secondary endpoints: collision-question incidence,
false reassurance, alternative observation controls, oracle pass@5, and costs.
Do not retrospectively promote a secondary endpoint because it is significant.

## Public data and split

Use the official Spider release's `dev.json`, original SQLite databases, and the
official distilled test-suite database archive. URLs and SHA-256 hashes are in
`asset_manifest.json`. No `test.json` or hidden evaluation server is used.

Database IDs are sorted by SHA-256 of JSON `["edbt-2027-collision-audit-v1", db_id]`.
The first four are pilot databases: orchestra, museum_visit, singer, flight_2.
Within each, select six questions by the same salted ID hash, giving 24 questions.
The other 16 databases provide **866 confirmation questions**. All remaining 144
questions on pilot databases are quarantined, not moved into confirmation.
`split_manifest.json` records every ID and original-database checksum.

This is a custom partition of public Spider dev, **not a full official dev score**.
It prevents experimental database overlap, not model pretraining contamination.
Schemas for all dev databases are exported during preparation; confirmation gold
labels are not consumed by generation or selection.

## Candidate generation

- First feasibility models: existing Qwen2.5-3B-Instruct Q8_0 and
  Llama-3.2-3B-Instruct Q8_0 weights, with distinct licenses and recorded hashes.
- Zero-shot question plus SQLite CREATE TABLE schema; no database rows, gold SQL,
  gold values, suite instances, retrieved solutions, or execution repair feedback.
- k=5 independent sampling calls per question, temperature 0.7, top_p=0.95,
  max new tokens 384, context 8192 per slot, four server slots and concurrent
  requests (pilot used one slot; a new pilot-only concurrency smoke check is not
  part of confirmation). Seeds are deterministic hashes
  of protocol seed 2701, question ID and sample index. Reproducible seeds do not
  imply bitwise-identical outputs across backends.
- Only a whole-response SQL fence is removed. No extraction of a convenient
  substring, query repair, value substitution, or gold-dependent postprocessing.
- A failed request is a terminal failed sample; truncations remain visible and
  their extracted SQL is executed as returned. No best-of-retry selection.
- Generated pools are immutable inputs shared by every selection rule.
- Exactly 4,330 calls per model for confirmation; 8,660 for two models. A larger
  model is a useful extension, not an already completed experiment.

## Selectors (no gold or suite access)

All ties select the earliest sample. No executable candidate means return the
first candidate as a scored failure rather than dropping the question.

| Selector | Definition |
|---|---|
| first | Sample 0, including invalid SQL |
| first_executable | First successful original-database execution |
| exact_sql | Largest exact trimmed SQL-string group, valid or invalid |
| exact_sql_executable | Same, restricted to executable samples |
| execution_bag | Largest identical typed row-bag group, including output arity |
| execution_ordered | Same, preserving returned row order for every candidate |
| execution_arity_blind | Bag grouping without arity; other conventions unchanged |
| execution_unique_sql | Bag grouping weighted by distinct trimmed SQL strings |
| execution_official | Original SQL, largest group under the official unordered result comparator |
| dail_sc | Released DAIL-SQL self-consistency aggregation, including its SQL preprocessing, with our bounded executor |

The bag fingerprint preserves numeric JSON types, column positions and duplicate
row multiplicity. It ignores column names and row ordering. This is intentionally
separate from the evaluator's allowed column permutations and gold-derived ordering.
The ordered variant is an observation sensitivity test, not a semantic SQL oracle.
“Structural voting” is **not implemented**; exact-string voting must not be renamed.

DAIL-SQL reference commit: `2061f68112222083134a0c9e2877961ff315ff44`,
`utils/post_process.py`. Its voting stage repairs spaced operators, removes all
DISTINCT tokens with sqlparse 0.5.3 (first parsed statement), and rewrites
YEAR(CURDATE()) to 2020. It ignores row order, permits column permutations, counts
repeated samples, skips failed executions, and uses earliest stable ties. The
returned query is the **original SQL**, not the rewritten voting SQL. We replicate
this stage, not DAIL-SQL's GPT-4 generator or few-shot retrieval. Two hundred fixed
synthetic pools test aggregation parity; pure comparator ASTs match exactly.
The original-SQL comparator vote isolates the aggregate effect of preprocessing,
not DISTINCT alone; report which transformations occur before attributing effects.

## Evaluation

1. Freeze selections and ledger hashes before loading any gold label.
2. Execute gold SQL and each candidate on the original database. Score using the
   six unchanged pure result-comparison functions from upstream commit
   `e97acc546ecbee8fa27fa8dbf025ef61493a876c`.
3. Execute on every `.sqlite` in the official suite directory for that database,
   including its original instance. Require an original pass **and** all suite
   passes for suite success. Do not substitute gold values; preserve DISTINCT.
4. Use the upstream convention `"order by" in gold_sql.lower()` for row ordering.
   No upstream YEAR/CURDATE or spaced-operator rewrites are applied. Consequently,
   call the score **comparator-compatible bounded suite pass**, not bit-identical
   official leaderboard accuracy. Record SQLite version and unsupported functions.
5. Original gold failure makes original scoring unavailable. Any gold suite
   failure makes that question's suite score unavailable for every method; report
   count, ID and cause separately. Candidate failures/timeouts are failures, not
   missing results. Return sizes above 10,000 rows / 4 MB are resource failures.
6. For each distinct-SQL pair inside an original typed-bag group, retain the first
   suite instance where both execute successfully but the comparator rejects
   equality. A timeout/error is not itself a semantic separation witness.
   Retain separated-pair IDs and candidate matches for **every** instance, enabling
   later schema-constraint sensitivity without selecting a favorable witness.

Four independent question workers evaluate the same per-query 2-second cap.
Each SQLite batch uses a child process and a wall-clock deadline. Original scoring
re-executes gold and every candidate, independently of the frozen voting results.
No generation server runs during primary evaluation. Question caches permit
resumption but reject provenance changes. Candidate result caps remain fixed.

Prespecified robustness analyses:

- Re-score the first 10 questions per confirmation database sorted by
  SHA-256 of JSON `["edbt-timeout-v1", id]` (160 total), on all instances with a
  10-second per-query cap. Re-execute original SQL as well; **do not reselect** or
  selectively change the primary 2-second results. Compare gold availability and
  every method's outcomes on matched questions. If any primary gold resource
  failures occur outside this panel, also diagnose all such cases separately;
  that diagnostic set does not replace the balanced sensitivity panel.
- Independently screen every suite instance against original SQLite-declared
  primary-key uniqueness, NOT NULL declarations and foreign-key relationships.
  Check original databases too. Retain violations and unsupported/missing-schema
  checks. Do not call this complete schema validity: CHECK constraints, triggers,
  collations, business rules and undeclared dependencies are not certified.
  Report separated pairs/questions on instances that pass these explicit checks;
  original-database agreement remains required. Report coverage and exclusions.
- Recompute each selection rule for prefixes k=1,3,5 of the *same* pools, retaining
  the k=5 evaluation-valid question set. This is a sampling-budget diagnostic, not
  an independently regenerated experiment.

Finite test suites may miss differences or encode assumptions that differ from
the intended task. Inspect concrete witnesses and labels; never silently relabel.
If two suite databases share bytes, report it; multiple files are not independent
experimental units. The original instance's presence in the archive is not a
held-out perturbation, and only changed-instance witnesses support that claim.

## Analysis and uncertainty

Questions are paired across selectors. Bootstrap **whole database clusters**,
4,000 replicates with seed 2701, and report micro-averaged paired rate differences.
Only four pilot clusters exist; their intervals are descriptive and unstable.
The planned 16-cluster confirmation still has limited precision. Repeated samples,
candidate pairs and suite instances are not independent observations.

Report question and distinct-pair collision counts, original/suite pass counts,
false reassurance conditional on original pass, and strata with explicit small
denominators. Include request failures, execution failures, truncations, duplicate
SQL frequency, tokens and measured generation time. Equal generated pools ensure
equal sampling budget, not equal selection latency. Do not infer performance
differences between hardware from runs with different models.

Secondary paired contrasts: typed-bag versus first-executable, DAIL-SC versus
original-SQL comparator vote, and each representation control versus typed-bag.
Report selection changes and wins/losses, database-level rates, and oracle pass@5.
Separate the gain due to executable filtering (first-executable minus first) from
the remaining voting gain (typed-bag minus first-executable). Also report expected
suite correctness of uniform sampling among executable candidates (fallback first
if none); this expectation uses all candidates, not an additional random draw.
Intervals are pointwise, without multiplicity adjustment; only the two model-wise
primary contrasts are primary. Do not claim family-wise significance.

## Confirmation / submission gates

Before confirmation: inspect pilot issues, finish faithful prior-work baseline and
evaluator parity checks, fix source hashes, and freeze model/runtime settings.
Revisions after seeing pilot outcomes are exploratory and must be disclosed.

Before submission:

- Execute both model families on all 866 confirmation questions, with no outcome
  filtering or cherry-picked subset. Add a stronger 7B–8B model if practical.
- Investigate gold failures and resource caps; report sensitivity under a longer
  timeout without selectively changing only one method's results.
- Audit at least a deterministic sample of all distinct witnessed mechanisms,
  including nonempty results; check witness schemas and relevant constraints.
- Demonstrate insight beyond “multiple database instances are a stricter test.”
  If result-representation controls never matter, report that rather than claim
  a new solution. If no new general insight survives, do not rush this to EDBT.
- Review related work again, add stronger baseline(s), finalize uncertainty and
  limitation statements, authors, artifact access and required disclosures.
