# Timeout-panel sample-size correction

Recorded after primary confirmation scoring, before any timeout-panel scoring.
The first sensitivity command stopped at its size assertion; it executed no SQL.

The frozen protocol incorrectly anticipated 160 questions from ten questions on
each of sixteen databases. `real_estate_properties` contains only **four** public
development questions. The other fifteen databases each contain at least ten.

Use the unchanged salted-hash ordering and take ten questions where available,
or all questions otherwise: 15 × 10 + 4 = **154**. Do not substitute six questions
from other databases, inspect outcomes to choose replacements, or duplicate the
four questions. This is a documented feasibility correction, not a change to
the primary study. The original protocol and lock remain unmodified.

The primary 866-question pools, selectors, scoring, and primary/secondary endpoint
definitions are unaffected. The corrected panel is near-balanced across all
sixteen databases, not exactly balanced. The paper must disclose the correction.

Separately, after finding that the two gold-unavailable references return 20,662
player rows, a **post-hoc** diagnostic raises the row cap to 50,000 for all
candidates on all gold-resource-failure questions in both models. Its ten-second
cap and unchanged 4 MB cap are recorded separately. It does not replace primary
results or the timeout panel. Worst-case bounds for unavailable primary cases
are also explicitly exploratory, not confidence intervals.
