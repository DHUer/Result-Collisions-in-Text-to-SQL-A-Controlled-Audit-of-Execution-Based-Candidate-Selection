# Data, software, model and template provenance

- Spider: [official website](https://yale-lily.github.io/spider),
  [repository](https://github.com/taoyds/spider). The repository has an Apache-2.0
  license; do not assume that one repository license resolves every underlying
  database's redistribution terms. Download data from the provider; raw archives
  and database contents are excluded from Git and the small code artifact.
  Cite Yu et al. (2018). No training/other/classical benchmark queries are studied.
- Test-suite evaluator: pinned commit in `asset_manifest.json`; Apache-2.0 license
  is retained unmodified in `vendor/test_suite/LICENSE`. Only six pure comparator
  functions are executed; upstream SQL, pickle and subprocess code is not run.
  Cite Zhong, Yu and Klein (2020). Archive checksums pin actual evaluated databases.
- DAIL-SQL: Gao et al., PVLDB 17(5):1132–1145 (2024), DOI
  `10.14778/3641204.3641221`. Unmodified `utils/post_process.py` and Apache-2.0
  license retained under `vendor/dail_sql/`, pinned to commit
  `2061f68112222083134a0c9e2877961ff315ff44`. Attribution: Alibaba Group, 2022–2023.
  The adapter reproduces released aggregation/preprocessing under our executor,
  not the entire DAIL-SQL generator. See the manifest and parity tests.
  sqlparse 0.5.3 is a pinned dependency (BSD-3-Clause).
- EDBT official template: files retained unmodified. Preserve embedded acmart
  licensing notices. EDBT's publication metadata is template boilerplate, not a
  claim that this draft has been accepted or assigned an ISBN.
- Libertinus Math 7.051: the exact math font requested by the official acmart
  class, supplied locally for older Tectonic bundles. Unmodified font and SIL OFL
  license under `vendor/fonts/`; download and file hashes in its manifest.
- Qwen2.5-3B-Instruct: [model card](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct),
  Qwen Research License for this 3B checkpoint (do not label it Apache-2.0).
  Existing GGUF hash is recorded in the run manifest.
- Llama-3.2-3B-Instruct: [model card](https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct),
  Llama 3.2 Community License and applicable use policy. Weights are not redistributed.
- llama.cpp: locally installed build 10621, commit `c1d0e7a00`, reported version
  0.3.0. Existing model-download provenance/licenses remain in `../models/` in
  this workspace; a clean reproduction supplies its own licensed model paths.
- New project code: no public-release license has been chosen on the author's
  behalf. Select an explicit license and check third-party terms before release.

This artifact is AI-assisted. Human authors must verify citations, experimental
interpretation, code safety and venue disclosure requirements before submission.
