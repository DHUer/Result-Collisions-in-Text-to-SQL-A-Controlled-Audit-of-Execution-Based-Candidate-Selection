# Literature and novelty boundary

Checked September 29–30, 2026. This is a focused check, not an exhaustive review.
The full texts/abstracts below informed the design. Preprints are labeled as such.

| Work | Already established | What this project must add |
|---|---|---|
| Gao et al., PVLDB 2024, *Text-to-SQL Empowered by Large Language Models: A Benchmark Evaluation* ([DOI](https://doi.org/10.14778/3641204.3641221), [code](https://github.com/BeachWang/DAIL-SQL)) | DAIL-SQL prompting/retrieval and released execution-based self-consistency aggregation. Released voting removes DISTINCT by default. | Separate generator quality from aggregation; explicitly compare original-SQL comparator voting with the released preprocessing package on identical pools. This is not a complete DAIL-SQL replication. |
| Zhong, Yu, Klein, EMNLP 2020, *Semantic Evaluation for Text-to-SQL with Distilled Test Suites* ([paper](https://aclanthology.org/2020.emnlp-main.29/)) | Single-database evaluation can falsely accept SQL; distilled suites improve evaluation. | Measure candidate-cluster heterogeneity and actual selection consequences, not rediscover the need for test suites. |
| Yang et al., SIGMOD/PACMMOD 2025, *Automated Validating and Fixing of Text-to-SQL Translation with Execution Consistency*, SQLDriller ([DOI](https://doi.org/10.1145/3725271), [PDF](https://ipads.se.sjtu.edu.cn/zh/publications/SQLDriller.pdf)) | Execution consistency, generated counterexample databases, LLM-based checking and repair; empty aggregates versus COUNT already discussed. | A fixed-pool, low-compute audit without claiming a new verifier or claiming NULL-versus-zero is a new distinction. |
| Kikot, Shulgin, Xu, May 2026 preprint, *Data-aware candidate selection in NL2SQL translation via small separating instances* ([arXiv](https://arxiv.org/abs/2605.12319), [code](https://github.com/staskikotx/SISelection)) | Candidate selection using small separating database instances and provenance, including LLM judgments. | Do not present counterexample-based candidate selection as new. This project withholds suites from all selectors and examines the measurement layer. |
| Richardson, July 2026 preprint, *What Predicts Correctness in Text-to-SQL? A Selective-Prediction Study* ([arXiv](https://arxiv.org/abs/2607.06799)) | String/structural/execution consistency, executability and other correctness/confidence predictors. | Do not claim the first comparison of consistency methods. Audit agreement that disappears across held-out database instances and its relation to representation choices. |
| Yu et al., EMNLP 2018, *Spider* ([paper](https://aclanthology.org/D18-1425/)) | Public multi-domain text-to-SQL benchmark with database schemas and executable reference SQL. | New analyses, not a new dataset claim. Public data may be in model training. |

## Proposed contribution, contingent on confirmation

1. Distinguish sampling repetition from agreement between **distinct generated SQL
   strings**. Count duplicate samples for ordinary voting, but count unique SQL
   pairs for collision diagnostics; use database-cluster uncertainty.
2. Jointly audit observation choices: typed row bags versus row sequences,
   explicit output arity versus arity-blind grouping, and sample versus unique-SQL
   vote weights. Never merge empty relations, scalar NULL and scalar zero.
3. Connect a witnessed collision to **selected-program correctness**, not merely
   to a low-confidence or disagreeing candidate somewhere in the pool.
4. Release exact pools, selection decisions, and separating witnesses so these
   claims can be checked without reproducing stochastic LLM generation.

These four items are a research hypothesis about a useful EA&B contribution, not
proof of novelty. A manuscript showing only “test suites are stricter than one
database,” or only a few cherry-picked mistakes, is not enough for EDBT.

## Constraints on claims

- A finite suite supplies counterexamples, not a proof of SQL equivalence.
- An empty result is not necessarily wrong or low confidence.
- Structural/string differences are not necessarily semantic differences.
- A changed selected index need not change the program or its correctness.
- Correctness is relative to the released gold SQL and the tested instances;
  ambiguous natural language and reference errors remain possible.
- The official comparator is arity-blind when both result lists are empty. That
  behavior alone is an implementation fact, not a publishable discovery.
- Our main typed-bag selector preserves column order and numeric type. It is an
  explicitly defined baseline, not a claim to reproduce every execution-voting
  implementation in prior work. The confirmation adapter reproduces DAIL-SQL's
  released aggregation/preprocessing stage under a declared bounded executor;
  it does not reproduce the published generator or its accuracy numbers.
