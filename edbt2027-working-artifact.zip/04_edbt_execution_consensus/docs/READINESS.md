# Readiness and handoff

Updated September 29–30, 2026. **Constructed working paper, not submission-ready.**

## Current confirmation evidence

The full reserved study is complete: 866 questions × 5 samples × 2 model families
= **8,660 model calls**, ten selectors and **66,314 question–suite-instance
evaluations**. There were no failed requests or token-cap truncations. Two original
gold queries return 20,662 rows, exceeding the 10,000-row cap; paired primary
scores use 864 questions per model.

Typed-bag suite pass: Qwen 472/864 and Llama 486/864, versus first-candidate
444/864 and 394/864. Filtering explains 89.3% and 84.8% of the net improvements;
additional voting beyond first-executable is small, with Qwen's interval crossing
zero. Full counts, intervals, null findings and limits are in
[CONFIRMATION_EVIDENCE.md](../reports/CONFIRMATION_EVIDENCE.md).

The frozen core source is unchanged. The pipeline includes a published-aggregation
baseline, per-database and k=1/3/5 analyses, all-instance constraint screening,
timeout sensitivity, a separate post-hoc row-cap diagnosis, and independent
witness/decision verification. The test suite now contains **33 passing tests**.
Current PDF format and verification outcomes are recorded in
`manuscript/format_audit.json` and `reports/confirmation_verification.json`.
The revised PDF is **10 A4 pages, with four vector figures and eight numbered
references**. Its format checks find zero overfull boxes, unresolved citations
or BibTeX warnings; all fonts are embedded. All 17,320 decisions and all 457
model-wise witnesses reproduced. The 154-question timeout panel shows no changes
to candidate/selected suite-pass outcomes on its 153 common evaluable questions
per model. These are completed checks, not promises of future evidence.

The planned 160-question timeout panel was infeasible: one database has four
questions. The documented correction uses all four and ten from each other
database (**154 total**), without substitution. It was made after primary scoring
but before sensitivity scoring. See `SENSITIVITY_AMENDMENT.md`; the original
protocol/lock and all primary results remain unchanged.

## Original pilot history (retained, not the current study size)

- New standalone project in `paper/04_edbt_execution_consensus/`; existing papers
  and experiments were not modified or reused as SQL results.
- EDBT 2027 CFP checked and official A4 template downloaded. Topical area: Natural
  language processing for databases. Category: Experiments, Analysis & Benchmarks.
- Focused literature review includes close SIGMOD 2025 and 2026 preprint work.
- Public Spider/suite archives downloaded and hash-pinned; database-disjoint split
  exported with separate inference inputs and evaluation labels.
- Read-only SQL execution, eight selectors, strict result accounting, pinned
  upstream pure comparator, collision witnesses, database-cluster bootstrap.
- Two actual local model runs: Qwen2.5-3B-Instruct Q8_0 and Llama-3.2-3B-Instruct
  Q8_0, 120 calls each. No paid service, no training, no request failures, no capped
  generations. The model servers launched for this task were stopped afterward.
- Both complete pilot suites evaluated and repeated, with all initial reports
  retained. Final repeat: 24 gold-evaluable questions for each family.
- EDBT LaTeX draft with numbered references, generated tables and three vector
  figures. Figures are measured results or explicitly labeled workflow diagrams.
- The original 26 tests passed. All 384 frozen pilot selector decisions reproduce from candidate
  outputs, both numeric reports reproduce, and all 26 saved witnesses were
  independently re-executed on database files differing from the original.
- The pre-confirmation draft was a six-page A4 PDF with seven numbered references and three vector figures; no overfull
  boxes, BibTeX warnings or unresolved citations in the final build. Author
  placeholders prevented submission readiness. That draft is archived under
  `artifacts/pre_confirmation_manuscript.zip`; it is not the updated paper.

## Measured repeat results, not confirmation

| Outcome | Qwen | Llama |
|---|---:|---:|
| First candidate: suite pass | 14/24 | 15/24 |
| First executable: suite pass | 15/24 | 19/24 |
| Execution-bag vote: original pass | 21/24 | 22/24 |
| Execution-bag vote: suite pass | 16/24 | 20/24 |
| Original-pass vote failing suite | 5/21 | 2/22 |
| Questions with a witnessed distinct-query collision | 5/24 | 5/24 |
| Separated / originally agreeing distinct SQL pairs | 6/31 | 20/62 |
| Arity-blind control changes selected sample | 0/24 | 0/24 |

This does **not** prove a new method or an EDBT-level contribution. No scalar-NULL
candidate appeared. Most vote false reassurance is in the `other` output stratum,
not empty/zero/NULL. Do not sell this as an established “empty-answer problem.”

## Development history and repeat

The initial implementation checked typed-bag agreement but did not explicitly
require pairwise official-comparator agreement on the original database before
looking for a suite separation. A review identified that row-order disagreement
could otherwise be misclassified. All pilot pairs were inspected: none had this
issue. The guard was added anyway, and **both complete evaluations** were repeated
with unchanged candidate pools, selections and two-second SQL budgets.

The initial Qwen run had a gold **batch wall-clock timeout** on question
`spider-dev-0245`, instance `flight_2v515nightpatch8.sqlite`, while local generation
and evaluation overlapped. The repeat, after stopping generation, had no gold
failures. Do not infer causation from that timing coincidence. Initial Qwen
suite denominators were 23; repeat denominators are 24. The original run remains
available. Llama's scored outcomes and collision counts did not change. No model
calls were rerun to obtain better answers.

## Optional additional experiments / GPU handoff

The initial confirmation is already measured locally. A larger third-family
model (Gemma-4-12B, reasoning disabled server-side) was then run under the
unchanged protocol as a post-confirmation extension on the same, already seen
split; see [CONFIRMATION_EVIDENCE.md](../reports/CONFIRMATION_EVIDENCE.md).
Another public dataset or independent candidate-pool replications would broaden
external validity further, but are not represented as completed work. Use new run
directories and a new prospective protocol for extensions. The RTX 5080 and Mac
Studio can run independently; distributed inference is unnecessary. Existing
confirmation data are no longer an unseen holdout for future design changes.

## Before submitting

Done: author block (seven authors, Qiu first and corresponding; affiliations
confirmed), MIT license (`LICENSE`, vendored Apache-2.0 code keeps its own),
Zenodo metadata (`.zenodo.json`), and a checksum-verified ZIP
(`artifacts/edbt2027-working-artifact.zip`, see `reports/package_manifest.json`).

Remaining:
- On Zenodo: New upload, "Reserve DOI", attach the ZIP, copy fields from
  `.zenodo.json`, publish. Optionally, replace the "DOI will be given in the final version" sentence in the
  Artifacts section of `manuscript/main.tex` with the DOI and rebuild.
- Author read-through of claims, references and the Gemma extension.
- Confirm the venue's disclosure policy, CMT conflicts and exact timezone.

Submission is October 7, 2026; first accept/reject/revise notification December 5.
A final decision after revision may occur January 27, 2027. Nothing has been
submitted, paid for, or pushed by this task.
