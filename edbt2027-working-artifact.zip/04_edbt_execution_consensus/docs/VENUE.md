# EDBT 2027 submission target

Checked September 29, 2026, America/Los_Angeles (September 30 UTC).
Primary source: [official research CFP](https://edbticdt2027.github.io/contents/EDBT_CFP.html).
The downloaded snapshot is [sources/edbt2027-cfp.html](sources/edbt2027-cfp.html).

## Fit and category

- Scope: **Data management and AI → Natural language processing for databases**.
- Additional topical fit: Tabular foundation models and LLMs.
- Paper category: **Experiments, Analysis & Benchmarks (EA&B)**, because the intended
  contribution is a detailed evaluation and new insight into existing selectors.
- The title must begin **[EA&B]**. If a genuinely new selector becomes the main
  contribution, reassess the category: the CFP directs new solutions to regular research.

## Third-cycle dates

| Event | Official date |
|---|---|
| Submission, still open at check time | October 7, 2026 |
| Author feedback | November 19, 2026 |
| Accept / reject / revise notification | December 5, 2026 |
| Revision | January 4, 2027 |
| Final accept / reject notification | January 27, 2027 |
| Camera-ready | February 10, 2027 |

The CFP literally states **“All times are 5pm PST”**, while the official
[important-dates page](https://edbticdt2027.github.io/contents/important_dates.html)
says **5pm PT**. October is normally daylight-saving time in California. Use the
earlier interpretation (5pm California time) for planning and confirm CMT/the
chairs' exact cutoff; never assume AoE. Target October 6 internally.
This schedule offers a **first decision in 2026**, not necessarily a final decision
or publication in 2026, and does not guarantee acceptance.

## Mandatory formatting and submission checks

- Official **A4** template, downloaded and retained unchanged under `vendor/edbt2027/`.
- At most **12 pages of content** for EA&B, plus unlimited references. The required
  **Artifacts** section directly before references is excluded from the page limit.
- **Single-anonymous**, not double-anonymous: real author names and affiliations
  must be on the PDF. The draft's explicit pending-author text is not acceptable
  for submission. Do not invent affiliations or ORCIDs.
- All authors need CMT accounts and ORCIDs; the CFP is stricter than the template's
  older comment about only the corresponding author needing an ORCID.
- Declare conflicts; CMT and PDF author lists must match. Three submissions per
  author per cycle. Title/author changes after submission are restricted.
- EA&B artifacts are mandatory. A supplement ZIP or accessible link is allowed;
  links must not monitor reviewer access. A private repo alone is insufficient.
- Do not submit substantially the same paper elsewhere simultaneously. The CFP
  has restrictions on resubmitting papers rejected in preceding EDBT cycles.
- The [scientific-misconduct policy](https://edbticdt2027.github.io/contents/guidelines-for-scientific-misconduct.html)
  permits AI-generated content but requires full disclosure. It recommends an
  acknowledgement naming tools and identifying affected content; AI systems
  cannot be authors. Basic spelling/grammar/translation assistance is exempt.
  This project's substantive AI-assisted code, analysis, figures and prose exceed
  that exemption. Human authors retain responsibility for all scientific content.

Submission portal: <https://cmt3.research.microsoft.com/EDBT2027>.
No submission, registration, payment, or publication commitment has been made.
