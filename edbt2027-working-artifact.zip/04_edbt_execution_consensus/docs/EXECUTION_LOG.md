# Confirmation execution notes

- The local protocol/source freeze preceded generation on September 30, 2026 UTC.
  The exact timestamp and hashes are in `confirmation_lock.json`.
- Qwen completed all 4,330 calls in 711.5804 seconds of generation-session wall
  time. Its completed pool and timing record are preserved.
- The first Llama launch was rejected before creating a run directory or making
  any model calls: the runner could not bind localhost port 18090 immediately
  after the Qwen server stopped. A read-only reproduction confirmed `Address
  already in use`; all protocol, config and frozen source hashes still matched.
  No existing service was stopped. The orchestration script was changed to use a
  separate port (18091) for Llama and to skip verified completed generations.
  This is an operational change outside the frozen experimental source; it does
  not alter prompts, samples, candidate ordering, model weights or scoring rules.
- All later evaluation/analysis diagnostics must remain explicit; primary ledgers
  are never silently replaced with a more favorable retry.
- Both primary studies completed: 8,660 calls, no request failures or token-cap
  truncations, 66,314 question–suite-instance evaluations. Both have the same two
  row-cap-related gold exclusions, independently diagnosed without replacing
  primary results. See `SENSITIVITY_AMENDMENT.md` for the infeasible 160-to-154
  timeout-panel count correction and separate post-hoc row-cap diagnostic.
- Verification reproduced all 17,320 decisions and 457 model-wise witnesses;
  all 1,732 real-pool DAIL aggregation comparisons passed. The revised paper
  passed A4, embedded-font, citation and overflow checks (10 pages, 4 figures,
  8 numbered references). Remaining submission issues are human/author/release
  decisions, not missing primary confirmation measurements.
