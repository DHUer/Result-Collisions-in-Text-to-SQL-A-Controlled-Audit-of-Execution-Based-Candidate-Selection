# Additional descriptive diagnostics

Added during confirmation generation, before confirmation SQL selection/scoring.
The frozen v0.2 protocol, primary endpoint and subsets are unchanged. These are
**exploratory descriptive decompositions**, not additional confirmatory tests.

For each evaluation-valid question, assign the typed-bag outcome to exactly one
of four categories, in this order:

1. The selected candidate passes the suite.
2. No candidate in the five-sample pool passes the suite.
3. The selected candidate fails, but a correct candidate belongs to the winning
   original-result group (within-group representative ambiguity).
4. The selected candidate fails, and correct candidates occur only outside the
   winning result group (between-group selection failure).

This distinguishes failures that more samples might address from failures of
selection on an already sufficient pool. The retrospective group oracle is not
a deployable method. Ties use the frozen rule, and suite labels can be imperfect.
Record winning group size, distinct SQL count and tied-top-group count. A mixed
group is not itself evidence of incorrect selected SQL: its representative may
be the correct member. Do not conflate collision incidence with selection error.

Additionally classify false reassurance as successful result mismatch, candidate
execution failure, or both. This diagnoses bounded-executor effects without
changing any score. If only an execution failure is present, do not describe that
case as a witnessed semantic difference.
