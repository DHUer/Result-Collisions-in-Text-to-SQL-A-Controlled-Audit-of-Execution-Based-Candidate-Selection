# Measured confirmation: llama3b

866 questions, 16 databases, 4,330 generated samples. This is a custom Spider-dev partition, not a full official leaderboard score.

| Selector | Original pass | Suite pass | False reassurance |
|---|---:|---:|---:|
| First | 442/864 | 394/864 | 48/442 |
| First executable | 533/864 | 472/864 | 61/533 |
| Exact SQL | 469/864 | 427/864 | 42/469 |
| Exact SQL, executable | 542/864 | 486/864 | 56/542 |
| Typed-bag vote | 552/864 | 486/864 | 66/552 |
| Ordered vote | 551/864 | 486/864 | 65/551 |
| Arity-blind vote | 552/864 | 486/864 | 66/552 |
| Unique-SQL vote | 551/864 | 484/864 | 67/551 |
| Comparator vote | 553/864 | 487/864 | 66/553 |
| DAIL-SC aggregation | 553/864 | 487/864 | 66/553 |

Paired intervals resample the 16 whole database clusters (4,000 replicates, seed 2701); they are pointwise, not multiplicity-adjusted. Two gold-reference row-limit failures are unavailable for every method.

See [the combined evidence report](../CONFIRMATION_EVIDENCE.md) for interpretation, constraint/resource checks, protocol amendments and limitations. DAIL-SC is the released aggregation stage, not an end-to-end DAIL-SQL replication. Human review and author/release details remain outstanding.
