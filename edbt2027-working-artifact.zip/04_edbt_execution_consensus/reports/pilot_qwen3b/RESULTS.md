# Exploratory Pilot: Qwen2.5-3B Q8_0

Measured results only. This custom Spider-dev partition is not a full benchmark score.

24 questions, 4 databases, 120 generated samples.

| Selector | Original pass | Suite pass | False reassurance |
|---|---:|---:|---:|
| first | 18/24 | 14/23 | 4/18 |
| first_executable | 20/24 | 15/23 | 4/19 |
| exact_sql | 19/24 | 15/23 | 4/19 |
| exact_sql_executable | 21/24 | 16/23 | 4/20 |
| execution_bag | 21/24 | 16/23 | 4/20 |
| execution_ordered | 21/24 | 16/23 | 4/20 |
| execution_arity_blind | 21/24 | 16/23 | 4/20 |
| execution_unique_sql | 20/24 | 15/23 | 4/19 |

Witnessed collisions: 5 questions; 6/31 distinct-SQL pairs with identical typed-bag observations separated on at least one official suite instance.

Pair counts are diagnostic, not independent statistical samples. Failure to find a witness does not establish semantic equivalence.

Candidate result categories: {'empty': 11, 'other': 95, 'scalar_zero': 3, 'invalid': 11}

Invalid-gold questions: 1; truncated responses: 0; request failures: 0.

No claim of improved selection, generality, novelty, or publication readiness follows from this pilot.
