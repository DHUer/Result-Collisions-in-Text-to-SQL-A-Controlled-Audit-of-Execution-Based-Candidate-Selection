# Post-Confirmation Extension: Gemma-4-12B

Measured results only. This custom Spider-dev partition is not a full benchmark score.

866 questions, 16 databases, 4330 generated samples.

| Selector | Original pass | Suite pass | False reassurance |
|---|---:|---:|---:|
| first | 688/864 | 639/864 | 49/688 |
| first_executable | 696/864 | 645/864 | 51/696 |
| exact_sql | 692/864 | 637/864 | 55/692 |
| exact_sql_executable | 695/864 | 639/864 | 56/695 |
| execution_bag | 696/864 | 644/864 | 52/696 |
| execution_ordered | 696/864 | 642/864 | 54/696 |
| execution_arity_blind | 696/864 | 644/864 | 52/696 |
| execution_unique_sql | 695/864 | 643/864 | 52/695 |
| execution_official | 696/864 | 644/864 | 52/696 |
| dail_sc | 694/864 | 641/864 | 53/694 |

Witnessed collisions: 39 questions; 61/633 distinct-SQL pairs with identical typed-bag observations separated on at least one official suite instance.

Pair counts are diagnostic, not independent statistical samples. Failure to find a witness does not establish semantic equivalence.

Candidate result categories: {'other': 3915, 'empty': 211, 'scalar_zero': 71, 'invalid': 128, 'scalar_null': 5}

Invalid-gold questions: 2; truncated responses: 12; request failures: 0.

No claim of improved selection, generality, novelty, or publication readiness follows from this pilot.
