# Confirmation evidence

Measured locally on an Apple M4 Max (64 GiB), September 30, 2026 UTC. These are
custom Spider-dev partition results, not an official full-dev leaderboard score.

## Scope

- 866 questions on 16 databases reserved from the four pilot databases.
- Qwen2.5-3B-Instruct Q8_0 and Llama-3.2-3B-Instruct Q8_0; five samples each:
  **8,660 actual calls**, zero request failures and zero token-cap truncations.
- Ten selectors share each immutable candidate pool. Choices precede gold access.
- **66,314 question–suite-instance evaluations** across the two models.
- Two reference queries exceed the 10,000-row cap, leaving **864 gold-valid
  questions per model**. The original gold queries return 20,662 player rows;
  their IDs are `spider-dev-0455` and `spider-dev-0456`.

## Main results

| Selector / diagnostic | Qwen | Llama |
|---|---:|---:|
| First candidate: suite pass | 444/864 | 394/864 |
| First executable: suite pass | 469/864 | 472/864 |
| Executable exact-string vote: suite pass | 472/864 | 486/864 |
| Typed-bag vote: suite pass | 472/864 | 486/864 |
| Published DAIL-SC aggregation: suite pass | 473/864 | 487/864 |
| Oracle pool pass@5 | 542/864 | 582/864 |
| Typed-bag original pass | 553/864 | 552/864 |
| Typed-bag false reassurance | 81/553 | 66/552 |
| Questions with witnessed collisions | 83/866 | 121/866 |
| Separated / eligible distinct-SQL pairs | 173/887 | 284/2159 |

Primary paired gain, typed-bag versus first: **+3.24 pp [1.75, 4.58]** for Qwen
and **+10.65 pp [8.30, 12.95]** for Llama. Intervals are pointwise 95% percentiles
from 4,000 whole-database bootstrap resamples; they are not multiplicity-adjusted.

The strongest interpretation is a **baseline-control finding**, not a new voting
algorithm: executable filtering accounts for 25/28 (89.3%) and 78/92 (84.8%) of
those net additional passes. Voting beyond filtering adds only **+0.35 pp
[-0.60, 1.24]** for Qwen and **+1.62 pp [0.53, 2.99]** for Llama. Do not claim
that voting has no benefit for either model, or that all its gains come from
answer agreement. Executable exact-string voting matches its aggregate totals.

DAIL's released DISTINCT-removing preprocessing changes six Qwen and four Llama
selected SQL programs, with one win and one loss in each model. Zero net accuracy
change is not the same as identical decisions. This reproduces the aggregation
stage under the bounded executor, not the complete published DAIL-SQL system.

## Failure decomposition and witnesses

| Typed-bag outcome category | Qwen | Llama |
|---|---:|---:|
| Correct selection | 472 | 486 |
| No correct candidate in pool | 322 | 282 |
| Wrong representative; correct candidate inside winning group | 17 | 26 |
| Correct candidates exist only outside winning group | 53 | 70 |

This decomposition is exploratory, specified during generation before scoring.
It separates a generation ceiling from within-group and between-group selection
failures. Collision pairs elsewhere in a pool are not automatically recoverable
selection errors. Most false-reassurance cases are outside empty/scalar-zero/NULL
categories (76/81 and 59/66), but this is a count statement, not a conditional-risk
comparison or an information-entropy measurement.

Two reproducible, post-hoc confirmation illustrations are in
`confirmation_examples.json`: unanimous scalar-1 agreement hides a multi-row
scalar-subquery problem on `network_1` (0912), while name-versus-identifier grouping
is separated on `concert_singer` (0036). Natural-language ambiguity and implicit
business rules still need human review.

## Robustness and reproducibility

- All 534 changed suite instances pass the limited original-declared PK/NOT-NULL/FK
  screen. Three original-database copies contain FK violations; all 457 model-wise
  pair witnesses still have a changed, screen-passing instance.
- `timeout_sensitivity.json` records the two-versus-ten-second comparison. The
  planned 160-question panel was infeasible because one database has only four
  questions; the documented correction uses 154 without replacement questions.
  Both caps have 153 gold-valid panel questions per model. **No candidate or
  selected-query suite-pass outcome changes** on that common set.
- `gold_row_cap_diagnostic.json` separately records a **post-hoc** 50,000-row-cap
  diagnosis of all gold-resource failures. Primary results remain unchanged.
  Both references become evaluable; the two added cases contribute zero to the
  typed-bag-minus-first paired difference for either model.
- `confirmation_verification.json` records numerical reproduction, all 17,320
  selector decisions, released-DAIL aggregation parity on 1,732 real pools, and
  independent re-execution of every stored pair witness.
  **All checks passed**, including all 457 model-wise pair witnesses.
- `confirmation_analysis.json` includes database-level effects, k=1/3/5 fixed-pool
  prefixes, pointwise intervals and the exact provenance chain.

Generation session wall times were 711.58 seconds (Qwen) and 789.06 seconds
(Llama), about 25 minutes total; SQL evaluation, verification and startup are
additional. No RTX 5080/Mac Studio performance comparison is claimed.

The protocol is a timestamped local freeze, not external preregistration.
Operational changes and the panel-size correction are disclosed in `docs/`.
The study remains limited to one public dataset, two 3B checkpoints, one pool per
question/model, and bounded benchmark-relative scoring. Real author details,
independent human scientific review, licensing and public artifact access remain
necessary before submission. Nothing has been pushed or submitted by this task.

## Post-confirmation extension: Gemma-4-12B (measured September 30, 2026)

Same frozen protocol, prompt, seeds, selectors and scorer on all 866 questions,
with `google/gemma-4-12B-it-qat-q4_0-gguf`. The only change is the server flag
`--reasoning-budget 0` (Gemma otherwise spends the 384-token cap on hidden
reasoning). This split was already analyzed, so it is a replication, not a fresh
holdout. Run: `runs/extension_gemma12b`; report: `reports/extension_gemma12b`;
paired analysis: `reports/extension_analysis.json`.

| Gemma-4-12B | Value |
|---|---:|
| Calls / request failures / truncations | 4,330 / 0 / 12 |
| Suite pass: first / first executable / bag / DAIL-SC | 639 / 645 / 644 / 641 of 864 |
| Bag − first (primary) | +0.6 pp [−0.1, +1.3] |
| Executable − first | +0.7 pp [+0.3, +1.1] |
| Bag − executable | −0.1 pp [−0.6, +0.4] |
| Oracle pass@5 | 665/864 |
| Failures with no correct candidate | 199/220 |
| Collision questions (pairs separated/eligible) | 39 (61/633) |

Reproduce: see RUNNING.md, "Gemma extension".
