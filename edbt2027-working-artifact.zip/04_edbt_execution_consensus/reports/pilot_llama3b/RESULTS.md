# Exploratory Pilot: Llama-3.2-3B Q8_0

Measured results only. This custom Spider-dev partition is not a full benchmark score.

24 questions, 4 databases, 120 generated samples.

| Selector | Original pass | Suite pass | False reassurance |
|---|---:|---:|---:|
| first | 17/24 | 15/24 | 2/17 |
| first_executable | 21/24 | 19/24 | 2/21 |
| exact_sql | 17/24 | 16/24 | 1/17 |
| exact_sql_executable | 20/24 | 19/24 | 1/20 |
| execution_bag | 22/24 | 20/24 | 2/22 |
| execution_ordered | 22/24 | 20/24 | 2/22 |
| execution_arity_blind | 22/24 | 20/24 | 2/22 |
| execution_unique_sql | 22/24 | 20/24 | 2/22 |

Witnessed collisions: 5 questions; 20/62 distinct-SQL pairs with identical typed-bag observations separated on at least one official suite instance.

Pair counts are diagnostic, not independent statistical samples. Failure to find a witness does not establish semantic equivalence.

Candidate result categories: {'empty': 11, 'other': 92, 'scalar_zero': 7, 'invalid': 10}

Invalid-gold questions: 0; truncated responses: 0; request failures: 0.

No claim of improved selection, generality, novelty, or publication readiness follows from this pilot.
