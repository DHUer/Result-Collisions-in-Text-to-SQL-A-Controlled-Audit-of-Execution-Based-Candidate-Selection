# Measured confirmation: qwen3b

866 questions, 16 databases, 4,330 generated samples. This is a custom Spider-dev partition, not a full official leaderboard score.

| Selector | Original pass | Suite pass | False reassurance |
|---|---:|---:|---:|
| First | 514/864 | 444/864 | 70/514 |
| First executable | 546/864 | 469/864 | 77/546 |
| Exact SQL | 531/864 | 455/864 | 76/531 |
| Exact SQL, executable | 551/864 | 472/864 | 79/551 |
| Typed-bag vote | 553/864 | 472/864 | 81/553 |
| Ordered vote | 553/864 | 472/864 | 81/553 |
| Arity-blind vote | 553/864 | 472/864 | 81/553 |
| Unique-SQL vote | 547/864 | 466/864 | 81/547 |
| Comparator vote | 553/864 | 473/864 | 80/553 |
| DAIL-SC aggregation | 552/864 | 473/864 | 79/552 |

Paired intervals resample the 16 whole database clusters (4,000 replicates, seed 2701); they are pointwise, not multiplicity-adjusted. Two gold-reference row-limit failures are unavailable for every method.

See [the combined evidence report](../CONFIRMATION_EVIDENCE.md) for interpretation, constraint/resource checks, protocol amendments and limitations. DAIL-SC is the released aggregation stage, not an end-to-end DAIL-SQL replication. Human review and author/release details remain outstanding.
