import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from collision_audit.common import ROOT, read_json
from collision_audit.execution import execute_batch
from collision_audit.generation import local_url, messages
from collision_audit.selection import choose, extract_sql, fingerprint, result_kind
from collision_audit.comparator import equivalent
from collision_audit.reporting import paired_cluster_interval


def result(rows, arity=1):
    return {"status": "ok", "rows": rows, "arity": arity}


def candidate(sql, rows, arity=1):
    return {"sql": sql, "execution": result(rows, arity)}


class SelectionTests(unittest.TestCase):
    def test_empty_zero_null_separate(self):
        cases = [result([]), result([[0]]), result([[None]]), result([[1]])]
        self.assertEqual([result_kind(r) for r in cases], ["empty", "scalar_zero", "scalar_null", "other"])
        self.assertEqual(len({fingerprint(r) for r in cases}), 4)

    def test_empty_arity(self):
        self.assertNotEqual(fingerprint(result([], 1)), fingerprint(result([], 2)))
        self.assertEqual(fingerprint(result([], 1), arity=False), fingerprint(result([], 2), arity=False))

    def test_bag_not_set(self):
        self.assertNotEqual(fingerprint(result([[1], [1]])), fingerprint(result([[1]])))

    def test_order_ablation(self):
        a, b = result([[1], [2]]), result([[2], [1]])
        self.assertEqual(fingerprint(a), fingerprint(b))
        self.assertNotEqual(fingerprint(a, ordered=True), fingerprint(b, ordered=True))

    def test_type_and_columns_preserved(self):
        self.assertNotEqual(fingerprint(result([[1]])), fingerprint(result([[1.0]])))
        self.assertNotEqual(fingerprint(result([[1, 2]], 2)), fingerprint(result([[2, 1]], 2)))

    def test_ties_earliest(self):
        pool = [candidate("a", [[1]]), candidate("b", [[2]]), candidate("c", [[2]]), candidate("d", [[1]])]
        self.assertEqual(choose(pool, "execution_bag"), 0)

    def test_errors_do_not_vote(self):
        pool = [{"sql": "bad", "execution": {"status": "error"}}] * 3 + [candidate("ok", [[1]])]
        self.assertEqual(choose(pool, "execution_bag"), 3)
        self.assertEqual(choose(pool[:3], "execution_bag"), 0)
        with self.assertRaises(ValueError):
            fingerprint(pool[0]["execution"])

    def test_unique_sql_votes(self):
        pool = [candidate("a", [[1]])] * 3 + [candidate("b", [[2]]), candidate("c", [[2]])]
        self.assertEqual(choose(pool, "execution_bag"), 0)
        self.assertEqual(choose(pool, "execution_unique_sql"), 3)

    def test_fence_extraction_only(self):
        self.assertEqual(extract_sql("```sql\nSELECT 1;\n```"), "SELECT 1;")
        self.assertEqual(extract_sql("Here: SELECT 1;"), "Here: SELECT 1;")
        self.assertEqual(extract_sql("SELECT 1; DROP TABLE x;"), "SELECT 1; DROP TABLE x;")


class IsolationTests(unittest.TestCase):
    def test_gold_field_rejected(self):
        case = {"id": "x", "db_id": "d", "question": "q", "schema": "s"}
        self.assertEqual(len(messages(case)), 2)
        case["gold_sql"] = "SELECT 999"
        with self.assertRaises(ValueError):
            messages(case)

    def test_remote_endpoint_rejected(self):
        for url in ("https://example.com", "http://example.com", "http://localhost.evil.com", "http://user:pass@localhost"):
            with self.subTest(url=url), self.assertRaises(ValueError):
                local_url(url)
        self.assertEqual(local_url("http://127.0.0.1:18089/"), "http://127.0.0.1:18089")

    def test_split_disjoint(self):
        path = ROOT / "docs/split_manifest.json"
        if not path.exists():
            self.skipTest("Run prepare for public data integration tests")
        m = read_json(path)
        self.assertFalse(set(m["pilot_databases"]) & set(m["confirmation_databases"]))
        sets = [set(v) for v in m["case_ids"].values()]
        self.assertEqual(sum(map(len, sets)), len(set.union(*sets)))


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = Path(self.temp.name) / "db.sqlite"
        with sqlite3.connect(self.db) as conn:
            conn.execute("CREATE TABLE t(x INTEGER)")
            conn.executemany("INSERT INTO t VALUES (?)", [(1,), (1,), (2,)])
        self.original_hash = hashlib.sha256(self.db.read_bytes()).hexdigest()

    def tearDown(self):
        self.assertEqual(hashlib.sha256(self.db.read_bytes()).hexdigest(), self.original_hash)
        self.temp.cleanup()

    def test_valid_select_cte_and_aggregate(self):
        rows = execute_batch(self.db, ["SELECT x FROM t", "WITH c AS (SELECT x FROM t) SELECT COUNT(*) FROM c", "SELECT SUM(x) FROM t WHERE 0", "SELECT x,x FROM t WHERE 0"])
        self.assertTrue(all(r["status"] == "ok" for r in rows))
        self.assertEqual(rows[1]["rows"], [[3]])
        self.assertEqual(result_kind(rows[2]), "scalar_null")
        self.assertEqual(rows[3]["arity"], 2)

    def test_mutations_and_file_access_denied(self):
        queries = ["DELETE FROM t", "DROP TABLE t", "INSERT INTO t VALUES (4)", "UPDATE t SET x=9", "CREATE TABLE z(x)", "ATTACH DATABASE ':memory:' AS evil", "PRAGMA writable_schema=ON", "SELECT load_extension('evil')", "SELECT readfile('/etc/passwd')", "SELECT 1; DELETE FROM t", "VACUUM", "SELECT random()"]
        self.assertTrue(all(r["status"] == "error" for r in execute_batch(self.db, queries)))

    def test_timeout(self):
        rows = execute_batch(self.db, ["WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c) SELECT SUM(x) FROM c"], timeout=0.05)
        self.assertEqual(rows[0]["status"], "timeout")

    def test_row_limit_is_not_empty(self):
        row = execute_batch(self.db, ["SELECT x FROM t"], max_rows=1)[0]
        self.assertEqual(row["status"], "resource_limit")

    def test_missing_database_not_created(self):
        missing = self.db.with_name("missing.sqlite")
        with self.assertRaises(FileNotFoundError):
            execute_batch(missing, ["SELECT 1"])
        self.assertFalse(missing.exists())


@unittest.skipUnless((ROOT / "vendor/test_suite/exec_eval.py").exists(), "Run prepare_assets first")
class ComparatorTests(unittest.TestCase):
    def test_upstream_arity_blind_empty_behavior(self):
        self.assertTrue(equivalent(result([], 1), result([], 2)))

    def test_column_permutation(self):
        self.assertTrue(equivalent(result([[1, "x"], [2, "y"]], 2), result([["x", 1], ["y", 2]], 2)))

    def test_multiplicity_order_null_zero(self):
        self.assertFalse(equivalent(result([[1], [1]]), result([[1]])))
        self.assertFalse(equivalent(result([[1], [2]]), result([[2], [1]]), ordered=True))
        self.assertTrue(equivalent(result([[1], [2]]), result([[2], [1]])))
        self.assertFalse(equivalent(result([[None]]), result([[0]])))

    def test_errors_are_never_equal(self):
        self.assertFalse(equivalent({"status": "error"}, {"status": "error"}))


class StatisticsTests(unittest.TestCase):
    def test_constant_paired_delta(self):
        cases = [{"evaluation_valid": True, "db_id": db, "suite_correct": [False, True], "selected": {"first": 0, "execution_bag": 1}} for db in ("a", "b", "b")]
        self.assertEqual(paired_cluster_interval(cases, "execution_bag", repeats=100), [1.0, 1.0])


if __name__ == "__main__":
    unittest.main()

