"""Parity with unchanged published aggregation code; not experimental results."""
import ast
import random
import re
import unittest
import sqlparse
from collision_audit.baselines import dail_preprocess, execution_choice, upstream_choice
from collision_audit.common import ROOT
from collision_audit.comparator import NAMES


class PublishedBaselineTests(unittest.TestCase):
    def test_aggregation_matches_released_code(self):
        rng = random.Random(2701)
        outputs = [
            {"status": "error"},
            {"status": "ok", "arity": 1, "rows": []},
            {"status": "ok", "arity": 2, "rows": []},
            {"status": "ok", "arity": 1, "rows": [[1], [2]]},
            {"status": "ok", "arity": 1, "rows": [[2], [1]]},
            {"status": "ok", "arity": 1, "rows": [[1], [1]]},
            {"status": "ok", "arity": 1, "rows": [[None]]},
            {"status": "ok", "arity": 2, "rows": [[1, "a"], [2, "b"]]},
            {"status": "ok", "arity": 2, "rows": [["a", 1], ["b", 2]]},
        ]
        for _ in range(200):
            rows = [rng.choice(outputs) for _ in range(5)]
            sqls = [f"SELECT {i}" for i in range(5)]
            pool = [{"sql": q, "execution": r} for q, r in zip(sqls, rows)]
            self.assertEqual(execution_choice(pool), upstream_choice(sqls, rows))

    def test_preprocessing_matches_released_code(self):
        tree = ast.parse((ROOT / "vendor/dail_sql/post_process.py").read_text())
        names = {"postprocess", "remove_distinct", "replace_cur_year"}
        nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
        self.assertEqual({n.name for n in nodes}, names)
        env = {"sqlparse": sqlparse, "re": re}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "upstream-pure-preprocess", "exec"), env)
        for sql in ["SELECT DISTINCT x FROM t", "SELECT count(DISTINCT x) FROM t", "SELECT 'distinct'", "SELECT x FROM t WHERE x > = 2", "SELECT YEAR(CURDATE())", "SELECT DISTINCT x; SELECT 9", ""]:
            try:
                expected = env["replace_cur_year"](env["remove_distinct"](env["postprocess"](sql)))
            except Exception:
                expected = ""
            self.assertEqual(dail_preprocess(sql), expected)

    def test_comparator_functions_identical(self):
        def pure(path):
            return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in NAMES}
        self.assertEqual(pure(ROOT / "vendor/dail_sql/post_process.py"), pure(ROOT / "vendor/test_suite/exec_eval.py"))

    def test_distinct_ablation_changes_vote_but_returns_original(self):
        from collision_audit.selection import choose
        def r(rows):
            return {"status": "ok", "arity": 1, "rows": rows}
        pool = [
            {"sql": "SELECT DISTINCT x FROM t", "execution": r([[1]]), "dail_execution": r([[1], [1]])},
            {"sql": "SELECT x FROM t", "execution": r([[1], [1]]), "dail_execution": r([[1], [1]])},
            {"sql": "SELECT x FROM t WHERE x=1", "execution": r([[1], [1]]), "dail_execution": r([[1], [1]])},
        ]
        self.assertEqual(choose(pool, "execution_official"), 1)
        self.assertEqual(choose(pool, "dail_sc"), 0)
        self.assertIn("DISTINCT", pool[choose(pool, "dail_sc")]["sql"])


if __name__ == "__main__":
    unittest.main()
