"""Orchestration regression tests; synthetic fixtures are not paper results."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from collision_audit.audit import evaluate_run
from collision_audit.common import digest, read_jsonl, write_json, write_jsonl
from collision_audit.selection import METHODS


def result(rows):
    return {"status": "ok", "arity": 1, "rows": rows}


class EvaluationPipelineTests(unittest.TestCase):
    def run_fixture(self, ordered=False, gold_error=False, duplicate=False):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            database = root / "instance.sqlite"
            database.write_bytes(b"synthetic test fixture, never opened by SQLite")
            gold = "SELECT gold" + (" ORDER BY x" if ordered else "")
            a, b = "SELECT a", "SELECT a" if duplicate else "SELECT b"
            original_b = [[2], [1]] if ordered else [[1], [2]]
            candidates = [{"sql": a, "execution": result([[1], [2]])}, {"sql": b, "execution": result(original_b)}]
            selections = {m: 0 for m in METHODS}
            write_jsonl(root / "selected.jsonl", [{"id": "case", "db_id": "db", "candidates": candidates, "selected": selections}])
            write_jsonl(root / "candidates.jsonl", [{"synthetic": True}])
            write_jsonl(root / "labels.jsonl", [{"id": "case", "db_id": "db", "gold_sql": gold}])
            write_json(root / "selection_manifest.json", {"selected_sha256": digest(root / "selected.jsonl"), "candidate_sha256": digest(root / "candidates.jsonl")})
            def execute(path, queries, **kwargs):
                mapping = {gold: {"status": "error"} if gold_error else result([[1], [2]]), a: result([[1], [2]])}
                if b != a:
                    mapping[b] = result([[2], [1]] if ordered else [[9]])
                return [mapping[q] for q in queries]
            with patch("collision_audit.audit.original_database", return_value=database), patch("collision_audit.audit.suite_databases", return_value=[database]), patch("collision_audit.audit.execute_batch", side_effect=execute):
                evaluate_run(root, root / "labels.jsonl")
            return read_jsonl(root / "evaluated.jsonl")[0]

    def test_original_order_difference_is_not_held_out_collision(self):
        row = self.run_fixture(ordered=True)
        self.assertEqual(row["typed_bag_pairs_observed"], 1)
        self.assertEqual(row["original_comparator_disagreement_pairs"], [[0, 1]])
        self.assertEqual(row["collision_pairs_observed"], 0)
        self.assertEqual(row["collision_pairs_separated"], 0)

    def test_real_instance_difference_is_witnessed(self):
        row = self.run_fixture()
        self.assertEqual(row["collision_pairs_observed"], 1)
        self.assertEqual(row["collision_pairs_separated"], 1)
        self.assertEqual(row["suite_correct"], [True, False])
        self.assertEqual(row["instances"][0]["separated_pairs"], [[0, 1]])

    def test_identical_sql_samples_are_not_distinct_pairs(self):
        row = self.run_fixture(duplicate=True)
        self.assertEqual(row["collision_pairs_observed"], 0)

    def test_gold_failure_is_unavailable_not_false(self):
        row = self.run_fixture(gold_error=True)
        self.assertFalse(row["evaluation_valid"])
        self.assertEqual(row["suite_correct"], [None, None])


if __name__ == "__main__":
    unittest.main()
