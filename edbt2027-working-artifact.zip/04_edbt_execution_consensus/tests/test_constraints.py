import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from audit_constraints import checks_for, screen


class ConstraintScreenTests(unittest.TestCase):
    def test_original_constraints_applied_to_relaxed_suite_schema(self):
        with tempfile.TemporaryDirectory() as tmp:
            original, perturbed = [Path(tmp) / p for p in ("original.sqlite", "perturbed.sqlite")]
            with sqlite3.connect(original) as conn:
                conn.executescript('CREATE TABLE parent(a INTEGER PRIMARY KEY); CREATE TABLE child(a INTEGER PRIMARY KEY, b INTEGER NOT NULL REFERENCES parent(a)); INSERT INTO parent VALUES (1); INSERT INTO child VALUES (1,1);')
            with sqlite3.connect(perturbed) as conn:
                conn.executescript('CREATE TABLE parent(a INTEGER); CREATE TABLE child(a INTEGER,b INTEGER); INSERT INTO parent VALUES (1); INSERT INTO child VALUES (1,9),(1,NULL);')
            spec = checks_for(original)
            self.assertTrue(screen(original, spec)["passed_screen"])
            checked = screen(perturbed, spec)
            self.assertFalse(checked["passed_screen"])
            self.assertEqual({r["kind"] for r in checked["checks"] if r["status"] == "violation"}, {"primary_key_duplicates", "declared_not_null", "foreign_key_orphans"})

    def test_composite_fk_nulls_and_quoted_identifiers(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "db.sqlite"
            with sqlite3.connect(path) as conn:
                conn.executescript('CREATE TABLE "p table" (a INTEGER,b INTEGER,PRIMARY KEY(a,b)); CREATE TABLE c (x INTEGER,y INTEGER,FOREIGN KEY(x,y) REFERENCES "p table"(a,b)); INSERT INTO "p table" VALUES(1,2); INSERT INTO c VALUES(1,2),(9,NULL);')
            self.assertTrue(screen(path, checks_for(path))["passed_screen"])


if __name__ == "__main__":
    unittest.main()
