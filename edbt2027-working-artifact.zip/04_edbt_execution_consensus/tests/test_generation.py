import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from collision_audit.common import read_json, read_jsonl, write_jsonl
from collision_audit.generation import generate


class ConcurrentGenerationTests(unittest.TestCase):
    def test_complete_terminal_failure_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            model = root / "model.gguf"
            model.write_bytes(b"synthetic fixture, not a model")
            inputs = root / "inputs.jsonl"
            write_jsonl(inputs, [{"id": "c", "db_id": "d", "question": "q", "schema": "s"}])
            calls = []
            def request(url, payload=None, **kwargs):
                if url.endswith("/props"):
                    return {}
                if url.endswith("/v1/models"):
                    return {"data": [{"id": "fixture"}]}
                calls.append(payload["seed"])
                if len(calls) == 1:
                    raise TimeoutError("deliberate terminal sample failure")
                time.sleep(0.002)
                return {"choices": [{"message": {"content": "SELECT 1"}, "finish_reason": "stop"}]}
            with patch("collision_audit.generation.request", side_effect=request):
                for _ in range(2):
                    generate(inputs, root / "run", "http://localhost:1234", model, "fixture", max_workers=4)
            rows = read_jsonl(root / "run/candidates.jsonl")
            self.assertEqual(len(calls), 5)
            self.assertEqual({r["sample"] for r in rows}, set(range(5)))
            self.assertEqual(sum(r["status"] != "ok" for r in rows), 1)
            self.assertTrue(read_json(root / "run/generation_completion.json")["complete"])


if __name__ == "__main__":
    unittest.main()
